import React from 'react';
import { Invoice } from '../types';
import { formatSAR, formatDate } from '../utils/zatca';
import { AlertTriangle, Trash2, X } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  invoice: Invoice | null;
  onClose: () => void;
  onConfirmDelete: (id: string) => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  invoice,
  onClose,
  onConfirmDelete,
}) => {
  if (!isOpen || !invoice) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-rose-400">
            <div className="p-2 bg-rose-500/10 border border-rose-500/20 rounded-lg">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Delete ZATCA Invoice</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300 leading-relaxed">
            Are you sure you want to delete this ZATCA invoice record? This action will permanently remove it from your history and recalculate your dashboard metrics.
          </p>

          {/* Invoice Summary Box */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Invoice Number:</span>
              <span className="font-mono font-bold text-emerald-400">{invoice.invoiceNumber}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Seller / Vendor:</span>
              <span className="font-medium text-slate-200 truncate max-w-[200px]">{invoice.sellerName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Issue Date:</span>
              <span className="text-slate-300">{formatDate(invoice.issueDate)}</span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-slate-800">
              <span className="text-slate-400 font-semibold">Total Amount:</span>
              <span className="font-mono font-bold text-white text-sm">{formatSAR(invoice.totalAmount)}</span>
            </div>
          </div>

          <p className="text-xs text-rose-400/90 font-medium flex items-center gap-1.5">
            <span>⚠️ Note: Deleted records cannot be restored.</span>
          </p>
        </div>

        {/* Action Footer */}
        <div className="px-6 py-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
          >
            Cancel
          </button>

          <button
            onClick={() => {
              onConfirmDelete(invoice.id);
              onClose();
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 active:bg-rose-700 rounded-lg shadow-md transition-colors"
            id="confirm-delete-invoice-btn"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Yes, Delete Invoice</span>
          </button>
        </div>

      </div>
    </div>
  );
};
