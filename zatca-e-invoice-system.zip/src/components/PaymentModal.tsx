import React, { useState } from 'react';
import { Invoice, PaymentStatus, PaymentMethod } from '../types';
import { formatSAR } from '../utils/zatca';
import { X, CreditCard, DollarSign, Calendar, CheckCircle2, History } from 'lucide-react';

interface PaymentModalProps {
  invoice: Invoice | null;
  isOpen: boolean;
  onClose: () => void;
  onSavePayment: (
    invoiceId: string,
    newStatus: PaymentStatus,
    paidAmount: number,
    paymentMethod: PaymentMethod,
    reference: string,
    notes: string
  ) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  invoice,
  isOpen,
  onClose,
  onSavePayment,
}) => {
  if (!isOpen || !invoice) return null;

  const [status, setStatus] = useState<PaymentStatus>(invoice.paymentStatus);
  const [paidAmount, setPaidAmount] = useState<number>(invoice.paidAmount || 0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Mada');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');

  const remainingAmount = Math.max(0, invoice.totalAmount - paidAmount);

  const handleStatusChange = (newStatus: PaymentStatus) => {
    setStatus(newStatus);
    if (newStatus === 'Paid') {
      setPaidAmount(invoice.totalAmount);
    } else if (newStatus === 'Unpaid') {
      setPaidAmount(0);
    }
  };

  const handleAmountChange = (amt: number) => {
    const validAmt = Math.min(Math.max(0, amt), invoice.totalAmount);
    setPaidAmount(validAmt);
    if (validAmt >= invoice.totalAmount) {
      setStatus('Paid');
    } else if (validAmt === 0) {
      setStatus('Unpaid');
    } else {
      setStatus('Partially Paid');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSavePayment(invoice.id, status, paidAmount, paymentMethod, reference, notes);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-lg">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Record & Manage Payment</h3>
              <p className="text-xs text-slate-400 font-mono">{invoice.invoiceNumber} • Total: {formatSAR(invoice.totalAmount)}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Payment Status Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-2">
              Payment Status
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleStatusChange('Paid')}
                className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all ${
                  status === 'Paid'
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                🟢 Paid
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('Partially Paid')}
                className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all ${
                  status === 'Partially Paid'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                🟡 Partially Paid
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('Unpaid')}
                className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all ${
                  status === 'Unpaid'
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700'
                }`}
              >
                🔴 Unpaid
              </button>
            </div>
          </div>

          {/* Amount Inputs */}
          <div className="grid grid-cols-2 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Paid Amount (SAR)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                max={invoice.totalAmount}
                value={paidAmount}
                onChange={(e) => handleAmountChange(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-emerald-400 font-bold font-mono outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Remaining Amount (SAR)
              </label>
              <div className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-rose-400 font-bold font-mono">
                {remainingAmount.toFixed(2)}
              </div>
            </div>
          </div>

          {/* Method & Ref */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white outline-none focus:border-blue-500"
              >
                <option value="Mada">Mada</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Visa/Mastercard">Visa / Mastercard</option>
                <option value="Cash">Cash</option>
                <option value="POS">POS Terminal</option>
                <option value="Cheque">Cheque</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Transaction Reference #
              </label>
              <input
                type="text"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="TXN-12345"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Payment Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Installment payment details..."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white outline-none focus:border-blue-500"
            />
          </div>

          {/* Existing Payment History Log */}
          {invoice.payments && invoice.payments.length > 0 && (
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <History className="w-3.5 h-3.5" />
                Existing Payment Records ({invoice.payments.length})
              </span>
              <div className="space-y-1.5 text-xs max-h-32 overflow-y-auto">
                {invoice.payments.map((p) => (
                  <div key={p.id} className="flex justify-between items-center bg-slate-900 p-2 rounded text-[11px]">
                    <div>
                      <span className="font-bold text-emerald-400">{formatSAR(p.amount)}</span>
                      <span className="text-slate-400 ml-2">via {p.method}</span>
                    </div>
                    <span className="text-slate-500 font-mono">{p.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors"
            >
              Save Payment Record
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
