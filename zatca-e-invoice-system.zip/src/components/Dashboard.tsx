import React from 'react';
import { DashboardMetrics } from '../types';
import { formatSAR } from '../utils/zatca';
import { FileText, CheckCircle2, Clock, AlertCircle, DollarSign, Percent, Receipt, ShieldAlert } from 'lucide-react';

interface DashboardProps {
  metrics: DashboardMetrics;
  isFiltered: boolean;
  onClearFilters: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ metrics, isFiltered, onClearFilters }) => {
  return (
    <div className="space-y-6">
      
      {/* Top Metric Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        {/* Total Invoices */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm hover:border-slate-700 transition-colors">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Invoices</span>
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white">{metrics.totalInvoicesCount}</span>
            <span className="text-xs text-slate-400">Recorded</span>
          </div>
        </div>

        {/* Paid Invoices */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm hover:border-emerald-500/30 transition-colors">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Paid</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-emerald-400">{metrics.paidInvoicesCount}</span>
            <span className="text-xs text-emerald-500/80 font-medium">🟢 Paid</span>
          </div>
        </div>

        {/* Partially Paid */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm hover:border-amber-500/30 transition-colors">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Partially Paid</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-amber-400">{metrics.partiallyPaidCount}</span>
            <span className="text-xs text-amber-500/80 font-medium">🟡 Partial</span>
          </div>
        </div>

        {/* Unpaid Invoices */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-sm hover:border-rose-500/30 transition-colors">
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Unpaid</span>
            <AlertCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-rose-400">{metrics.unpaidInvoicesCount}</span>
            <span className="text-xs text-rose-500/80 font-medium">🔴 Pending</span>
          </div>
        </div>

      </div>

      {/* Main Admin Dashboard Table as strictly requested by user */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-md overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">📊 ZATCA Financial Summary</h2>
            {isFiltered && (
              <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-md font-medium">
                Filtered Results
              </span>
            )}
          </div>

          {isFiltered && (
            <button
              onClick={onClearFilters}
              className="text-xs text-slate-400 hover:text-white underline font-medium"
            >
              Reset Filters
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-slate-200">
            <thead className="text-xs uppercase bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th scope="col" className="px-6 py-3 font-semibold">Dashboard Field</th>
                <th scope="col" className="px-6 py-3 font-semibold text-right">Amount / Count</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              
              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 flex items-center gap-2 text-slate-300">
                  <FileText className="w-4 h-4 text-slate-400" />
                  Total Invoices
                </td>
                <td className="px-6 py-3 text-right font-semibold text-white">
                  {metrics.totalInvoicesCount}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 text-slate-300">Paid Invoices</td>
                <td className="px-6 py-3 text-right font-semibold text-emerald-400">
                  {metrics.paidInvoicesCount}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 text-slate-300">Unpaid Invoices</td>
                <td className="px-6 py-3 text-right font-semibold text-rose-400">
                  {metrics.unpaidInvoicesCount}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 text-slate-300">Partially Paid</td>
                <td className="px-6 py-3 text-right font-semibold text-amber-400">
                  {metrics.partiallyPaidCount}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 text-slate-300">Total Subtotal</td>
                <td className="px-6 py-3 text-right font-mono font-medium text-slate-200">
                  {formatSAR(metrics.totalSubtotal)}
                </td>
              </tr>

              {/* Total Discount - BOLD */}
              <tr className="bg-amber-950/20 hover:bg-amber-950/30 transition-colors font-bold text-amber-300 border-y border-amber-500/20">
                <td className="px-6 py-3 flex items-center gap-2">
                  <Percent className="w-4 h-4 text-amber-400" />
                  Total Discount
                </td>
                <td className="px-6 py-3 text-right font-mono text-amber-300">
                  {formatSAR(metrics.totalDiscount)}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 text-slate-300">Taxable Amount</td>
                <td className="px-6 py-3 text-right font-mono font-medium text-slate-200">
                  {formatSAR(metrics.taxableAmount)}
                </td>
              </tr>

              {/* Total VAT Amount - BOLD */}
              <tr className="bg-blue-950/20 hover:bg-blue-950/30 transition-colors font-bold text-blue-300 border-y border-blue-500/20">
                <td className="px-6 py-3 flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-blue-400" />
                  Total VAT Amount (15%)
                </td>
                <td className="px-6 py-3 text-right font-mono text-blue-300">
                  {formatSAR(metrics.totalVatAmount)}
                </td>
              </tr>

              {/* Total Invoice Amount - BOLD */}
              <tr className="bg-emerald-950/30 hover:bg-emerald-950/40 transition-colors font-bold text-emerald-300 border-y border-emerald-500/30 text-base">
                <td className="px-6 py-3.5 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-emerald-400" />
                  Total Invoice Amount
                </td>
                <td className="px-6 py-3.5 text-right font-mono text-emerald-300 text-lg">
                  {formatSAR(metrics.totalInvoiceAmount)}
                </td>
              </tr>

              <tr className="hover:bg-slate-800/30 transition-colors">
                <td className="px-6 py-3 text-slate-300">Total Paid Amount</td>
                <td className="px-6 py-3 text-right font-mono font-medium text-emerald-400">
                  {formatSAR(metrics.totalPaidAmount)}
                </td>
              </tr>

              {/* Outstanding Amount - BOLD */}
              <tr className="bg-rose-950/30 hover:bg-rose-950/40 transition-colors font-bold text-rose-300 border-t border-rose-500/30">
                <td className="px-6 py-3.5 flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-rose-400" />
                  Outstanding Amount
                </td>
                <td className="px-6 py-3.5 text-right font-mono text-rose-300 text-base">
                  {formatSAR(metrics.outstandingAmount)}
                </td>
              </tr>

            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
