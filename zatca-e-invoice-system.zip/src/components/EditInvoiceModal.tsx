import React, { useState, useEffect } from 'react';
import { Invoice, LineItem, PaymentStatus, InvoicePhase } from '../types';
import {
  calculateInvoiceTotals,
  encodeZATCATLV,
  validateKSACompanyVat,
} from '../utils/zatca';
import {
  X,
  Save,
  Plus,
  Trash2,
  FileText,
  Building,
  User,
  Calculator,
  AlertCircle,
  QrCode,
  ShieldCheck,
} from 'lucide-react';

interface EditInvoiceModalProps {
  isOpen: boolean;
  invoice: Invoice | null;
  onClose: () => void;
  onSaveInvoice: (updatedInvoice: Invoice) => void;
}

export const EditInvoiceModal: React.FC<EditInvoiceModalProps> = ({
  isOpen,
  invoice,
  onClose,
  onSaveInvoice,
}) => {
  if (!isOpen || !invoice) return null;

  // Header Details
  const [invoiceNumber, setInvoiceNumber] = useState(invoice.invoiceNumber || '');
  const [issueDate, setIssueDate] = useState(invoice.issueDate || '');
  const [issueTime, setIssueTime] = useState(invoice.issueTime || '12:00');
  const [phase, setPhase] = useState<InvoicePhase>(invoice.phase || 'Phase 1 (Simplified)');

  // Seller Details
  const [sellerName, setSellerName] = useState(invoice.sellerName || '');
  const [sellerNameAr, setSellerNameAr] = useState(invoice.sellerNameAr || '');
  const [sellerVatNumber, setSellerVatNumber] = useState(invoice.sellerVatNumber || '');
  const [sellerAddress, setSellerAddress] = useState(invoice.sellerAddress || '');

  // Buyer Details
  const [buyerName, setBuyerName] = useState(invoice.buyerName || '');
  const [buyerVatNumber, setBuyerVatNumber] = useState(invoice.buyerVatNumber || '');
  const [buyerAddress, setBuyerAddress] = useState(invoice.buyerAddress || '');

  // Line Items
  const [items, setItems] = useState<LineItem[]>(
    invoice.items && invoice.items.length > 0
      ? invoice.items
      : [
          {
            id: 'item-1',
            description: 'Item Description',
            quantity: 1,
            unitPrice: 100,
            discount: 0,
            vatRate: invoice.vatRate || 15,
            taxableAmount: 100,
            vatAmount: 15,
            totalAmount: 115,
          },
        ]
  );

  // Financial Settings
  const [vatRate, setVatRate] = useState<number>(invoice.vatRate || 15);
  const [invoiceDiscount, setInvoiceDiscount] = useState<number>(0);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>(
    invoice.paymentStatus || 'Unpaid'
  );
  const [paidAmount, setPaidAmount] = useState<number>(invoice.paidAmount || 0);
  const [notes, setNotes] = useState<string>(invoice.notes || '');

  // Error state
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Reset form when active invoice changes
  useEffect(() => {
    if (invoice) {
      setInvoiceNumber(invoice.invoiceNumber || '');
      setIssueDate(invoice.issueDate || '');
      setIssueTime(invoice.issueTime || '12:00');
      setPhase(invoice.phase || 'Phase 1 (Simplified)');

      setSellerName(invoice.sellerName || '');
      setSellerNameAr(invoice.sellerNameAr || '');
      setSellerVatNumber(invoice.sellerVatNumber || '');
      setSellerAddress(invoice.sellerAddress || '');

      setBuyerName(invoice.buyerName || '');
      setBuyerVatNumber(invoice.buyerVatNumber || '');
      setBuyerAddress(invoice.buyerAddress || '');

      setItems(
        invoice.items && invoice.items.length > 0
          ? invoice.items
          : [
              {
                id: 'item-1',
                description: 'Service / Product',
                quantity: 1,
                unitPrice: 100,
                discount: 0,
                vatRate: invoice.vatRate || 15,
                taxableAmount: 100,
                vatAmount: 15,
                totalAmount: 115,
              },
            ]
      );

      setVatRate(invoice.vatRate || 15);
      setInvoiceDiscount(0);
      setPaymentStatus(invoice.paymentStatus || 'Unpaid');
      setPaidAmount(invoice.paidAmount || 0);
      setNotes(invoice.notes || '');
      setErrorMsg('');
    }
  }, [invoice]);

  // Recalculate Totals whenever line items, discounts, or VAT rates change
  const calculations = React.useMemo(() => {
    return calculateInvoiceTotals(items, invoiceDiscount, vatRate);
  }, [items, invoiceDiscount, vatRate]);

  // Handle line item field updates
  const handleItemChange = (
    id: string,
    field: keyof LineItem,
    val: string | number
  ) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === id) {
          return { ...item, [field]: val };
        }
        return item;
      })
    );
  };

  const handleAddItem = () => {
    const newItem: LineItem = {
      id: 'item-' + Date.now(),
      description: 'New Product / Service',
      quantity: 1,
      unitPrice: 0,
      discount: 0,
      vatRate: vatRate,
      taxableAmount: 0,
      vatAmount: 0,
      totalAmount: 0,
    };
    setItems((prev) => [...prev, newItem]);
  };

  const handleRemoveItem = (id: string) => {
    if (items.length <= 1) {
      setErrorMsg('Invoice must contain at least one line item.');
      return;
    }
    setItems((prev) => prev.filter((it) => it.id !== id));
    setErrorMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!sellerName.trim()) {
      setErrorMsg('Seller / Company Name is required.');
      return;
    }

    if (!sellerVatNumber.trim()) {
      setErrorMsg('Seller VAT Registration Number is required.');
      return;
    }

    if (!validateKSACompanyVat(sellerVatNumber)) {
      setErrorMsg('KSA VAT number must be 15 digits, starting and ending with 3 (e.g., 300000000000003).');
      return;
    }

    if (items.length === 0) {
      setErrorMsg('Please add at least one line item.');
      return;
    }

    const total = calculations.totalAmount;
    let computedPaid = paidAmount;
    if (paymentStatus === 'Paid') {
      computedPaid = total;
    } else if (paymentStatus === 'Unpaid') {
      computedPaid = 0;
    } else if (paymentStatus === 'Partially Paid') {
      if (computedPaid <= 0 || computedPaid >= total) {
        computedPaid = total / 2;
      }
    }

    const remaining = Math.max(0, total - computedPaid);

    // Format ISO timestamp for ZATCA TLV encoding (Tag 3)
    const formattedTimestamp = `${issueDate}T${issueTime}:00Z`;

    // Re-generate ZATCA TLV Base64 QR Tag
    const updatedQRBase64 = encodeZATCATLV({
      sellerName: sellerName.trim(),
      vatNumber: sellerVatNumber.trim(),
      timestamp: formattedTimestamp,
      totalAmount: calculations.totalAmount,
      vatAmount: calculations.vatAmount,
      invoiceHash: invoice.zatcaHash,
    });

    const updatedInvoice: Invoice = {
      ...invoice,
      invoiceNumber: invoiceNumber.trim() || invoice.invoiceNumber,
      issueDate: issueDate || invoice.issueDate,
      issueTime: issueTime || invoice.issueTime,
      phase,
      sellerName: sellerName.trim(),
      sellerNameAr: sellerNameAr.trim(),
      sellerVatNumber: sellerVatNumber.trim(),
      sellerAddress: sellerAddress.trim(),
      buyerName: buyerName.trim(),
      buyerVatNumber: buyerVatNumber.trim(),
      buyerAddress: buyerAddress.trim(),
      items: calculations.itemsWithCalculations,
      subtotal: calculations.subtotal,
      discount: calculations.discount,
      taxableAmount: calculations.taxableAmount,
      vatRate,
      vatAmount: calculations.vatAmount,
      totalAmount: calculations.totalAmount,
      paymentStatus,
      paidAmount: computedPaid,
      remainingAmount: remaining,
      qrBase64: updatedQRBase64,
      notes: notes.trim(),
      updatedAt: new Date().toISOString(),
    };

    onSaveInvoice(updatedInvoice);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col my-8 max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Edit ZATCA Invoice
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-emerald-400">
                  {invoice.invoiceNumber}
                </span>
              </h3>
              <p className="text-xs text-slate-400">Modify invoice details, items, VAT, and update ZATCA TLV QR code</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          
          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* SECTION 1: Invoice Header & Meta */}
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 space-y-4">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <QrCode className="w-4 h-4 text-emerald-400" />
              Invoice Metadata & Phase
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Invoice Number</label>
                <input
                  type="text"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Issue Date</label>
                <input
                  type="date"
                  value={issueDate}
                  onChange={(e) => setIssueDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Issue Time</label>
                <input
                  type="time"
                  value={issueTime}
                  onChange={(e) => setIssueTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">ZATCA Standard Phase</label>
                <select
                  value={phase}
                  onChange={(e) => setPhase(e.target.value as InvoicePhase)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="Phase 1 (Simplified)">Phase 1 (Simplified)</option>
                  <option value="Phase 2 (Integration/Standard)">Phase 2 (Integration)</option>
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 2: Seller & Buyer Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Seller Info */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Building className="w-4 h-4 text-emerald-400" />
                Seller / Vendor Information
              </h4>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Company Name (English) *</label>
                <input
                  type="text"
                  value={sellerName}
                  onChange={(e) => setSellerName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Company Name (Arabic - optional)</label>
                <input
                  type="text"
                  value={sellerNameAr}
                  onChange={(e) => setSellerNameAr(e.target.value)}
                  placeholder="اسم الشركة بالعربية"
                  dir="rtl"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500 text-right"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">KSA VAT Registration No. (15 Digits) *</label>
                <input
                  type="text"
                  value={sellerVatNumber}
                  onChange={(e) => setSellerVatNumber(e.target.value)}
                  maxLength={15}
                  placeholder="300000000000003"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-emerald-400 font-mono focus:outline-none focus:border-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Seller Address</label>
                <input
                  type="text"
                  value={sellerAddress}
                  onChange={(e) => setSellerAddress(e.target.value)}
                  placeholder="Riyadh, Kingdom of Saudi Arabia"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Buyer Info */}
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <User className="w-4 h-4 text-blue-400" />
                Buyer / Customer Details (Optional)
              </h4>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Buyer / Client Name</label>
                <input
                  type="text"
                  value={buyerName}
                  onChange={(e) => setBuyerName(e.target.value)}
                  placeholder="ACME Corporation KSA"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Buyer VAT Number (B2B)</label>
                <input
                  type="text"
                  value={buyerVatNumber}
                  onChange={(e) => setBuyerVatNumber(e.target.value)}
                  maxLength={15}
                  placeholder="300012345600003"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-blue-400 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Buyer Address</label>
                <input
                  type="text"
                  value={buyerAddress}
                  onChange={(e) => setBuyerAddress(e.target.value)}
                  placeholder="Jeddah, Saudi Arabia"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Payment Status</label>
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="Paid">🟢 Paid (Fully Cleared)</option>
                  <option value="Unpaid">🔴 Unpaid</option>
                  <option value="Partially Paid">🟡 Partially Paid</option>
                </select>
              </div>
            </div>

          </div>

          {/* SECTION 3: Line Items Table */}
          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Calculator className="w-4 h-4 text-emerald-400" />
                Line Items & Pricing
              </h4>
              <button
                type="button"
                onClick={handleAddItem}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold transition-colors shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Line Item</span>
              </button>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded-lg">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-950 text-slate-400 text-[10px] uppercase font-semibold">
                    <th className="p-2.5">Item Description</th>
                    <th className="p-2.5 w-20 text-center">Qty</th>
                    <th className="p-2.5 w-28 text-right">Unit Price (SAR)</th>
                    <th className="p-2.5 w-24 text-right">Discount (SAR)</th>
                    <th className="p-2.5 w-28 text-right">Total (SAR)</th>
                    <th className="p-2.5 w-12 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {items.map((item, idx) => {
                    const lineSub = item.quantity * item.unitPrice;
                    const lineTaxable = Math.max(0, lineSub - (item.discount || 0));
                    const lineVat = lineTaxable * (vatRate / 100);
                    const lineTotal = lineTaxable + lineVat;

                    return (
                      <tr key={item.id || idx} className="hover:bg-slate-900/50">
                        <td className="p-2">
                          <input
                            type="text"
                            value={item.description}
                            onChange={(e) =>
                              handleItemChange(item.id, 'description', e.target.value)
                            }
                            placeholder="Product or service description"
                            className="w-full bg-slate-900 border border-slate-700/80 rounded px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500"
                            required
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                'quantity',
                                Math.max(1, parseInt(e.target.value, 10) || 1)
                              )
                            }
                            className="w-full bg-slate-900 border border-slate-700/80 rounded px-2 py-1.5 text-center text-white font-mono focus:outline-none focus:border-emerald-500"
                            required
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={item.unitPrice}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                'unitPrice',
                                parseFloat(e.target.value) || 0
                              )
                            }
                            className="w-full bg-slate-900 border border-slate-700/80 rounded px-2 py-1.5 text-right text-white font-mono focus:outline-none focus:border-emerald-500"
                            required
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={item.discount}
                            onChange={(e) =>
                              handleItemChange(
                                item.id,
                                'discount',
                                parseFloat(e.target.value) || 0
                              )
                            }
                            className="w-full bg-slate-900 border border-slate-700/80 rounded px-2 py-1.5 text-right text-amber-400 font-mono focus:outline-none focus:border-emerald-500"
                          />
                        </td>
                        <td className="p-2 text-right font-mono font-bold text-emerald-400">
                          {lineTotal.toFixed(2)}
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1 text-slate-500 hover:text-rose-400 rounded transition-colors"
                            title="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Live Calculation Summary */}
            <div className="flex flex-col sm:flex-row justify-between items-start pt-3 gap-4 border-t border-slate-800">
              <div className="space-y-2 w-full sm:w-auto">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">VAT Rate %</label>
                  <input
                    type="number"
                    value={vatRate}
                    onChange={(e) => setVatRate(parseFloat(e.target.value) || 15)}
                    className="w-28 bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="w-full sm:w-64 space-y-1.5 font-mono text-right bg-slate-950 p-3 rounded-lg border border-slate-800">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span>{calculations.subtotal.toFixed(2)} SAR</span>
                </div>
                <div className="flex justify-between text-amber-400">
                  <span>Total Discount:</span>
                  <span>-{calculations.discount.toFixed(2)} SAR</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Taxable Amount:</span>
                  <span>{calculations.taxableAmount.toFixed(2)} SAR</span>
                </div>
                <div className="flex justify-between text-blue-400">
                  <span>VAT ({vatRate}%):</span>
                  <span>+{calculations.vatAmount.toFixed(2)} SAR</span>
                </div>
                <div className="flex justify-between font-bold text-white text-sm pt-1 border-t border-slate-800">
                  <span>Total Amount:</span>
                  <span className="text-emerald-400">{calculations.totalAmount.toFixed(2)} SAR</span>
                </div>
              </div>
            </div>

          </div>

        </form>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <span className="text-slate-500 text-[11px] flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            ZATCA TLV Base64 QR code will automatically update on save
          </span>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSubmit}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 rounded-lg shadow-md transition-colors"
              id="save-edit-invoice-btn"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
