import React, { useState, useEffect, useRef } from 'react';
import { Invoice, LineItem, PaymentStatus, InputMethod, AppSettings, InvoicePhase } from '../types';
import { decodeZATCATLV, encodeZATCATLV, calculateInvoiceTotals, generatePhase2SecurityData } from '../utils/zatca';
import jsQR from 'jsqr';
import { X, Camera, Plus, Trash2, QrCode, ClipboardCheck, Sparkles, CheckCircle2, AlertCircle, Upload, ShieldCheck } from 'lucide-react';

interface QRInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveInvoice: (newInvoice: Invoice) => void;
  settings: AppSettings;
  nextInvoiceNumber: string;
}

export const QRInputModal: React.FC<QRInputModalProps> = ({
  isOpen,
  onClose,
  onSaveInvoice,
  settings,
  nextInvoiceNumber,
}) => {
  const [activeTab, setActiveTab] = useState<'scan' | 'manual' | 'paste'>('scan');

  // Scanner state
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const animationFrameId = useRef<number | null>(null);

  // Paste Base64 State
  const [pasteText, setPasteText] = useState('');
  const [decodedData, setDecodedData] = useState<ReturnType<typeof decodeZATCATLV> | null>(null);
  const [pasteError, setPasteError] = useState<string | null>(null);

  // Manual Form State
  const [invoiceNumber, setInvoiceNumber] = useState(nextInvoiceNumber);
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0]);
  const [issueTime, setIssueTime] = useState('12:00');
  
  const [sellerName, setSellerName] = useState(settings.companyName);
  const [sellerVatNumber, setSellerVatNumber] = useState(settings.vatNumber);
  const [sellerAddress, setSellerAddress] = useState(settings.companyAddress);

  const [buyerName, setBuyerName] = useState('');
  const [buyerVatNumber, setBuyerVatNumber] = useState('');

  const [vatRate, setVatRate] = useState(settings.defaultVatRate);
  const [invoiceDiscount, setInvoiceDiscount] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Paid');
  const [inputPhase, setInputPhase] = useState<InvoicePhase>(settings.defaultPhase);

  const [lineItems, setLineItems] = useState<LineItem[]>([
    {
      id: 'item-1',
      description: 'Consulting & Technical Services',
      quantity: 1,
      unitPrice: 1000,
      discount: 0,
      vatRate: settings.defaultVatRate,
      taxableAmount: 1000,
      vatAmount: 150,
      totalAmount: 1150,
    },
  ]);

  useEffect(() => {
    setInvoiceNumber(nextInvoiceNumber);
    setVatRate(settings.defaultVatRate);
    setSellerName(settings.companyName);
    setSellerVatNumber(settings.vatNumber);
  }, [nextInvoiceNumber, settings]);

  // Handle Camera Scanning Stream
  useEffect(() => {
    if (isOpen && activeTab === 'scan') {
      startCameraScanner();
    } else {
      stopCameraScanner();
    }

    return () => {
      stopCameraScanner();
    };
  }, [isOpen, activeTab]);

  const startCameraScanner = async () => {
    setCameraError(null);
    setIsScanning(true);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.play();
        animationFrameId.current = requestAnimationFrame(scanQRCodeFromVideo);
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError('Unable to access camera. Please allow camera permissions or upload a QR image/paste Base64 text.');
      setIsScanning(false);
    }
  };

  const stopCameraScanner = () => {
    setIsScanning(false);
    if (animationFrameId.current) {
      cancelAnimationFrame(animationFrameId.current);
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const scanQRCodeFromVideo = () => {
    if (!videoRef.current || !canvasRef.current) return;

    if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const ctx = canvas.getContext('2d');

      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          handleScannedQRString(code.data);
          stopCameraScanner();
          return;
        }
      }
    }

    animationFrameId.current = requestAnimationFrame(scanQRCodeFromVideo);
  };

  // Image Upload QR Scanner
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data) {
            handleScannedQRString(code.data);
          } else {
            alert('No valid QR code could be detected in this image.');
          }
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleScannedQRString = (qrString: string) => {
    const decoded = decodeZATCATLV(qrString);
    if (!decoded) {
      alert('The QR Code scanned is not a valid ZATCA Base64 TLV invoice code.');
      return;
    }

    saveZatcaDecodedInvoice(decoded, 'QR Scan');
  };

  // Paste Base64 Handler
  const handlePasteChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setPasteText(text);
    setPasteError(null);

    if (text.trim()) {
      const decoded = decodeZATCATLV(text);
      if (decoded) {
        setDecodedData(decoded);
      } else {
        setDecodedData(null);
        setPasteError('Invalid ZATCA Base64 TLV format. Please ensure you pasted Tag-Length-Value encoded Base64.');
      }
    } else {
      setDecodedData(null);
    }
  };

  const handleConfirmPasteSave = () => {
    if (!decodedData) return;
    saveZatcaDecodedInvoice(decodedData, 'Base64 Paste');
  };

  // Shared Helper to Save Decoded QR Invoice
  const saveZatcaDecodedInvoice = (decoded: ReturnType<typeof decodeZATCATLV>, inputMethod: InputMethod) => {
    if (!decoded) return;

    const security = generatePhase2SecurityData();
    const calculatedTotals = calculateInvoiceTotals([], 0, vatRate);

    // Estimate line subtotal before VAT
    const totalAmount = decoded.totalAmount || 1150;
    const vatAmount = decoded.vatAmount || 150;
    const taxableAmount = Math.max(0, totalAmount - vatAmount);

    const newInvoice: Invoice = {
      id: 'inv-' + Date.now(),
      invoiceNumber: invoiceNumber || 'INV-' + Math.floor(1000 + Math.random() * 9000),
      uuid: security.uuid,
      issueDate: decoded.timestamp ? decoded.timestamp.split('T')[0] : new Date().toISOString().split('T')[0],
      issueTime: decoded.timestamp && decoded.timestamp.includes('T') ? decoded.timestamp.split('T')[1].substring(0, 5) : '12:00',
      sellerName: decoded.sellerName || 'ZATCA Registered Merchant',
      sellerVatNumber: decoded.vatNumber || '300000000000003',
      buyerName: buyerName || 'Walk-in Customer / Retail',
      buyerVatNumber: buyerVatNumber || '',
      items: [
        {
          id: 'item-scanned',
          description: 'ZATCA Decoded Products & Services',
          quantity: 1,
          unitPrice: taxableAmount,
          discount: 0,
          vatRate: vatRate,
          taxableAmount: taxableAmount,
          vatAmount: vatAmount,
          totalAmount: totalAmount,
        },
      ],
      subtotal: taxableAmount,
      discount: 0,
      taxableAmount: taxableAmount,
      vatRate: vatRate,
      vatAmount: vatAmount,
      totalAmount: totalAmount,
      paymentStatus: paymentStatus,
      paidAmount: paymentStatus === 'Paid' ? totalAmount : 0,
      remainingAmount: paymentStatus === 'Paid' ? 0 : totalAmount,
      payments: paymentStatus === 'Paid' ? [
        {
          id: 'pay-' + Date.now(),
          amount: totalAmount,
          date: new Date().toISOString().split('T')[0],
          method: 'Mada',
          notes: 'Full payment registered upon QR scan import',
        }
      ] : [],
      inputMethod: inputMethod,
      phase: decoded.invoiceHash ? 'Phase 2 (Integration/Standard)' : 'Phase 1 (Simplified)',
      qrBase64: decoded.rawBase64 || encodeZATCATLV({
        sellerName: decoded.sellerName,
        vatNumber: decoded.vatNumber,
        timestamp: decoded.timestamp,
        totalAmount: totalAmount,
        vatAmount: vatAmount,
      }),
      zatcaHash: decoded.invoiceHash || security.invoiceHash,
      isClearedByZATCA: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSaveInvoice(newInvoice);
    onClose();
  };

  // Manual Line Item Controls
  const handleAddItem = () => {
    setLineItems((prev) => [
      ...prev,
      {
        id: 'item-' + Date.now(),
        description: '',
        quantity: 1,
        unitPrice: 0,
        discount: 0,
        vatRate: vatRate,
        taxableAmount: 0,
        vatAmount: 0,
        totalAmount: 0,
      },
    ]);
  };

  const handleRemoveItem = (id: string) => {
    if (lineItems.length <= 1) return;
    setLineItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleItemChange = (id: string, field: keyof LineItem, val: any) => {
    setLineItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const updated = { ...item, [field]: val };
          // recalculate
          const lineSub = updated.quantity * updated.unitPrice;
          const lineTaxable = Math.max(0, lineSub - (updated.discount || 0));
          const lineVat = lineTaxable * (vatRate / 100);
          return {
            ...updated,
            taxableAmount: lineTaxable,
            vatAmount: lineVat,
            totalAmount: lineTaxable + lineVat,
          };
        }
        return item;
      })
    );
  };

  // Calculate overall form totals in real-time
  const calculated = calculateInvoiceTotals(lineItems, invoiceDiscount, vatRate);

  const handleSaveManualInvoice = (e: React.FormEvent) => {
    e.preventDefault();

    const timestampISO = `${issueDate}T${issueTime}:00Z`;
    const security = generatePhase2SecurityData();

    const qrBase64 = encodeZATCATLV({
      sellerName,
      vatNumber: sellerVatNumber,
      timestamp: timestampISO,
      totalAmount: calculated.totalAmount,
      vatAmount: calculated.vatAmount,
      invoiceHash: inputPhase === 'Phase 2 (Integration/Standard)' ? security.invoiceHash : undefined,
    });

    const paidAmt = paymentStatus === 'Paid' ? calculated.totalAmount : 0;

    const newInvoice: Invoice = {
      id: 'inv-' + Date.now(),
      invoiceNumber: invoiceNumber || nextInvoiceNumber,
      uuid: security.uuid,
      issueDate,
      issueTime,
      sellerName,
      sellerVatNumber,
      sellerAddress,
      buyerName: buyerName || 'General Buyer',
      buyerVatNumber,
      items: calculated.itemsWithCalculations,
      subtotal: calculated.subtotal,
      discount: calculated.discount,
      taxableAmount: calculated.taxableAmount,
      vatRate,
      vatAmount: calculated.vatAmount,
      totalAmount: calculated.totalAmount,
      paymentStatus,
      paidAmount: paidAmt,
      remainingAmount: calculated.totalAmount - paidAmt,
      payments: paymentStatus === 'Paid' ? [
        {
          id: 'pay-' + Date.now(),
          amount: calculated.totalAmount,
          date: issueDate,
          method: 'Bank Transfer',
          notes: 'Full payment registered during manual entry',
        }
      ] : [],
      inputMethod: 'Manual',
      phase: inputPhase,
      qrBase64,
      zatcaHash: security.invoiceHash,
      isClearedByZATCA: inputPhase === 'Phase 2 (Integration/Standard)',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSaveInvoice(newInvoice);
    onClose();
  };

  // Sample ZATCA Base64 string for quick testing
  const handleFillSampleBase64 = () => {
    const sampleTLVB64 = encodeZATCATLV({
      sellerName: 'Riyadh Commercial Trading Co.',
      vatNumber: '300123456700003',
      timestamp: new Date().toISOString(),
      totalAmount: 1150.00,
      vatAmount: 150.00,
      invoiceHash: 'MEQCIDxZATCAPhase2SampleHash2026Base64==',
    });
    setPasteText(sampleTLVB64);
    const decoded = decodeZATCATLV(sampleTLVB64);
    setDecodedData(decoded);
    setPasteError(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden flex flex-col my-8 max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">📷 ZATCA QR Input & Invoice Creator</h3>
              <p className="text-xs text-slate-400">Phase 1 & Phase 2 QR Decoder & Calculation Engine</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            id="close-qr-modal-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('scan')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'scan'
                ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
            id="tab-scan-qr"
          >
            <Camera className="w-4 h-4" />
            Scan QR Code
          </button>

          <button
            onClick={() => setActiveTab('manual')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'manual'
                ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
            id="tab-manual-entry"
          >
            <Plus className="w-4 h-4" />
            Manual Entry
          </button>

          <button
            onClick={() => setActiveTab('paste')}
            className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider text-center border-b-2 transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'paste'
                ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
            id="tab-paste-base64"
          >
            <ClipboardCheck className="w-4 h-4" />
            Paste ZATCA Base64
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* TAB 1: SCAN QR CODE */}
          {activeTab === 'scan' && (
            <div className="space-y-6 text-center">
              
              <div className="relative max-w-sm mx-auto bg-slate-950 border-2 border-dashed border-emerald-500/40 rounded-2xl overflow-hidden aspect-square flex flex-col items-center justify-center p-2">
                
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover rounded-xl"
                />
                <canvas ref={canvasRef} className="hidden" />

                {/* Overlaid Scanning Viewfinder */}
                {isScanning && (
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                    <div className="w-56 h-56 border-2 border-emerald-400/80 rounded-xl relative animate-pulse">
                      <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-emerald-400"></div>
                      <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-emerald-400"></div>
                      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-emerald-400"></div>
                      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-emerald-400"></div>
                    </div>
                  </div>
                )}

                {cameraError && (
                  <div className="p-4 bg-rose-950/60 text-rose-300 rounded-xl text-xs space-y-2 border border-rose-500/30">
                    <AlertCircle className="w-6 h-6 mx-auto text-rose-400" />
                    <p>{cameraError}</p>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <label className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors">
                  <Upload className="w-4 h-4 text-emerald-400" />
                  <span>Upload QR Image File</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="qr-image-upload-input"
                  />
                </label>

                <button
                  onClick={handleFillSampleBase64}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-xs font-semibold rounded-lg border border-emerald-500/30 transition-colors"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Test Sample QR Code</span>
                </button>
              </div>

              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Align the ZATCA E-Invoice QR code inside the frame. The system will automatically decode Tag 1 through Tag 9 and save to your invoice history.
              </p>

            </div>
          )}

          {/* TAB 2: MANUAL ENTRY FORM */}
          {activeTab === 'manual' && (
            <form onSubmit={handleSaveManualInvoice} className="space-y-6">
              
              {/* Invoice Meta Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Invoice Number</label>
                  <input
                    type="text"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Issue Date</label>
                  <input
                    type="date"
                    value={issueDate}
                    onChange={(e) => setIssueDate(e.target.value)}
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">ZATCA Phase</label>
                  <select
                    value={inputPhase}
                    onChange={(e) => setInputPhase(e.target.value as InvoicePhase)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                  >
                    <option value="Phase 1 (Simplified)">Phase 1 (Simplified)</option>
                    <option value="Phase 2 (Integration/Standard)">Phase 2 (Integration / Standard)</option>
                  </select>
                </div>
              </div>

              {/* Parties Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Seller Box */}
                <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    Seller Information
                  </h4>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Seller Name</label>
                    <input
                      type="text"
                      value={sellerName}
                      onChange={(e) => setSellerName(e.target.value)}
                      required
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Seller VAT Number (15 Digits)</label>
                    <input
                      type="text"
                      value={sellerVatNumber}
                      onChange={(e) => setSellerVatNumber(e.target.value)}
                      required
                      placeholder="300000000000003"
                      maxLength={15}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                </div>

                {/* Buyer Box */}
                <div className="bg-slate-950/40 p-4 rounded-xl border border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                    Buyer Information
                  </h4>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Buyer / Client Name</label>
                    <input
                      type="text"
                      value={buyerName}
                      onChange={(e) => setBuyerName(e.target.value)}
                      placeholder="Client Co. Ltd"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Buyer VAT Number (Optional)</label>
                    <input
                      type="text"
                      value={buyerVatNumber}
                      onChange={(e) => setBuyerVatNumber(e.target.value)}
                      placeholder="300999999900003"
                      maxLength={15}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                </div>

              </div>

              {/* Line Items Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Line Items & Services
                  </h4>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="inline-flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Item
                  </button>
                </div>

                <div className="space-y-2">
                  {lineItems.map((item, idx) => (
                    <div
                      key={item.id}
                      className="grid grid-cols-12 gap-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800 items-center text-xs"
                    >
                      <div className="col-span-12 sm:col-span-5">
                        <label className="block text-[10px] text-slate-400 mb-0.5">Description</label>
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                          placeholder="Product or service description"
                          required
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                      </div>

                      <div className="col-span-4 sm:col-span-2">
                        <label className="block text-[10px] text-slate-400 mb-0.5">Qty</label>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(item.id, 'quantity', parseFloat(e.target.value) || 1)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                        />
                      </div>

                      <div className="col-span-4 sm:col-span-2">
                        <label className="block text-[10px] text-slate-400 mb-0.5">Unit Price (SAR)</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                        />
                      </div>

                      <div className="col-span-3 sm:col-span-2">
                        <label className="block text-[10px] text-slate-400 mb-0.5">Discount (SAR)</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={item.discount}
                          onChange={(e) => handleItemChange(item.id, 'discount', parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-amber-400 font-mono"
                        />
                      </div>

                      <div className="col-span-1 flex justify-end">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id)}
                          disabled={lineItems.length <= 1}
                          className="p-1 text-slate-500 hover:text-rose-400 disabled:opacity-30"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* VAT & Calculations Breakdown */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">
                      VAT Percentage Rate (%)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={vatRate}
                        onChange={(e) => setVatRate(parseFloat(e.target.value) || 0)}
                        className="w-24 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-bold font-mono"
                      />
                      <span className="text-xs text-slate-400">Standard KSA VAT is 15%</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Payment Status</label>
                    <select
                      value={paymentStatus}
                      onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:border-emerald-500 outline-none"
                    >
                      <option value="Paid">🟢 Paid</option>
                      <option value="Unpaid">🔴 Unpaid</option>
                      <option value="Partially Paid">🟡 Partially Paid</option>
                    </select>
                  </div>
                </div>

                {/* Calculation Flow Summary */}
                <div className="pt-3 border-t border-slate-800 text-xs space-y-1.5 font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal:</span>
                    <span>{calculated.subtotal.toFixed(2)} SAR</span>
                  </div>
                  <div className="flex justify-between text-amber-400">
                    <span>Discount:</span>
                    <span>-{calculated.discount.toFixed(2)} SAR</span>
                  </div>
                  <div className="flex justify-between text-slate-200">
                    <span>Taxable Amount:</span>
                    <span>{calculated.taxableAmount.toFixed(2)} SAR</span>
                  </div>
                  <div className="flex justify-between text-blue-400 font-semibold">
                    <span>VAT ({vatRate}%):</span>
                    <span>+{calculated.vatAmount.toFixed(2)} SAR</span>
                  </div>
                  <div className="flex justify-between text-emerald-400 font-bold text-sm pt-1 border-t border-slate-800">
                    <span>Total Invoice Amount:</span>
                    <span>{calculated.totalAmount.toFixed(2)} SAR</span>
                  </div>
                </div>
              </div>

              {/* Submit Manual Invoice */}
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm"
                >
                  Save & Generate ZATCA QR
                </button>
              </div>

            </form>
          )}

          {/* TAB 3: PASTE ZATCA BASE64 TEXT */}
          {activeTab === 'paste' && (
            <div className="space-y-6">
              
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-300">
                    Paste ZATCA QR Base64 Encoded Text
                  </label>
                  <button
                    onClick={handleFillSampleBase64}
                    className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
                  >
                    Paste Sample TLV Code
                  </button>
                </div>
                <textarea
                  rows={4}
                  value={pasteText}
                  onChange={handlePasteChange}
                  placeholder="e.g. AQI...== (Paste ZATCA TLV Base64 String Here)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-emerald-300 focus:border-emerald-500 outline-none"
                  id="paste-base64-textarea"
                />
                {pasteError && (
                  <p className="text-xs text-rose-400 mt-1">{pasteError}</p>
                )}
              </div>

              {/* Live Decoded TLV Tag Preview */}
              {decodedData && (
                <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/30 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4" />
                    Decoded ZATCA TLV Structure
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 1: Seller Name</span>
                      <span className="font-bold text-white">{decodedData.sellerName}</span>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 2: VAT Registration Number</span>
                      <span className="font-mono font-bold text-blue-400">{decodedData.vatNumber}</span>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 3: Timestamp</span>
                      <span className="font-mono text-slate-300">{decodedData.timestamp}</span>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 4: Total Amount (VAT Incl.)</span>
                      <span className="font-mono font-bold text-emerald-400">{decodedData.totalAmount.toFixed(2)} SAR</span>
                    </div>

                    <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 5: VAT Amount</span>
                      <span className="font-mono font-bold text-amber-400">{decodedData.vatAmount.toFixed(2)} SAR</span>
                    </div>

                    {decodedData.invoiceHash && (
                      <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 col-span-2">
                        <span className="text-[10px] text-slate-400 block font-semibold">Tag 6: Phase 2 Cryptographic Hash</span>
                        <span className="font-mono text-[10px] text-purple-300 truncate block">{decodedData.invoiceHash}</span>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={handleConfirmPasteSave}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
                    id="save-pasted-qr-btn"
                  >
                    Confirm & Save to Invoice History
                  </button>
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
