import React, { useState } from 'react';
import { AppSettings, InvoicePhase } from '../types';
import { X, Settings, ShieldCheck, Percent, Building } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
}) => {
  if (!isOpen) return null;

  const [vatRate, setVatRate] = useState(settings.defaultVatRate);
  const [companyName, setCompanyName] = useState(settings.companyName);
  const [companyNameAr, setCompanyNameAr] = useState(settings.companyNameAr);
  const [vatNumber, setVatNumber] = useState(settings.vatNumber);
  const [companyAddress, setCompanyAddress] = useState(settings.companyAddress);
  const [defaultPhase, setDefaultPhase] = useState<InvoicePhase>(settings.defaultPhase);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      ...settings,
      defaultVatRate: vatRate,
      companyName,
      companyNameAr,
      vatNumber,
      companyAddress,
      defaultPhase,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">ZATCA VAT & Admin Configuration</h3>
              <p className="text-xs text-slate-400">Configure global tax rate and merchant VAT credentials</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 text-xs">
          
          {/* VAT Percentage Override Box */}
          <div className="bg-slate-950 p-4 rounded-xl border border-emerald-500/30 space-y-2">
            <label className="block text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <Percent className="w-4 h-4" />
              Standard System VAT Rate (%)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min="0"
                max="100"
                step="0.1"
                value={vatRate}
                onChange={(e) => setVatRate(parseFloat(e.target.value) || 0)}
                required
                className="w-28 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-emerald-400 font-bold font-mono focus:border-emerald-500 outline-none"
              />
              <p className="text-[11px] text-slate-400">
                Admin can adjust VAT % when required. Standard Saudi KSA VAT rate is <strong>15%</strong>.
              </p>
            </div>
          </div>

          {/* Merchant Company Details */}
          <div className="space-y-3 bg-slate-950/40 p-4 rounded-xl border border-slate-800">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Building className="w-4 h-4 text-blue-400" />
              Merchant Seller Information
            </h4>

            <div>
              <label className="block text-slate-400 mb-1">Company English Name</label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Company Arabic Name (اسم الشركة بالعربي)</label>
              <input
                type="text"
                value={companyNameAr}
                onChange={(e) => setCompanyNameAr(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">VAT Registration Number (15 Digits)</label>
              <input
                type="text"
                maxLength={15}
                value={vatNumber}
                onChange={(e) => setVatNumber(e.target.value)}
                required
                placeholder="300000000000003"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 font-mono text-blue-400 font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Merchant Registered Address</label>
              <input
                type="text"
                value={companyAddress}
                onChange={(e) => setCompanyAddress(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white"
              />
            </div>
          </div>

          {/* Phase Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Default ZATCA Compliance Mode
            </label>
            <select
              value={defaultPhase}
              onChange={(e) => setDefaultPhase(e.target.value as InvoicePhase)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white outline-none focus:border-emerald-500"
            >
              <option value="Phase 1 (Simplified)">Phase 1 (Simplified QR Code & Basic TLV)</option>
              <option value="Phase 2 (Integration/Standard)">Phase 2 (Standard B2B / B2C + Cryptographic Stamp Hash)</option>
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm transition-colors"
            >
              Save Configuration
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
