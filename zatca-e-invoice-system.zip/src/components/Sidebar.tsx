import React from 'react';
import {
  FileText,
  ShieldAlert,
  Truck,
  Navigation,
  Settings,
  X,
  QrCode,
  ShieldCheck,
  ChevronRight,
  Database,
  Building2,
  Users,
} from 'lucide-react';
import { AppPanel, AppSettings } from '../types';

interface SidebarProps {
  activePanel: AppPanel;
  onSelectPanel: (panel: AppPanel) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  totalInvoicesCount: number;
  settings: AppSettings;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activePanel,
  onSelectPanel,
  isMobileOpen,
  onCloseMobile,
  totalInvoicesCount,
  settings,
}) => {
  const navItems: {
    id: AppPanel;
    label: string;
    labelAr: string;
    icon: React.ReactNode;
    badge?: string;
    badgeColor?: string;
  }[] = [
    {
      id: 'invoices',
      label: 'ZATCA Invoices',
      labelAr: 'فواتير زاتكا',
      icon: <FileText className="w-5 h-5" />,
      badge: `${totalInvoicesCount}`,
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    },
    {
      id: 'admin',
      label: 'Admin Panel',
      labelAr: 'لوحة الإدارة والامتثال',
      icon: <ShieldAlert className="w-5 h-5" />,
      badge: 'Executive',
      badgeColor: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    },
    {
      id: 'dispatcher',
      label: 'Dispatcher Panel',
      labelAr: 'لوحة الحركة والشحن',
      icon: <Truck className="w-5 h-5" />,
      badge: 'Fleet',
      badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    },
    {
      id: 'driver',
      label: 'Driver Mobile',
      labelAr: 'تطبيق السائق',
      icon: <Navigation className="w-5 h-5" />,
      badge: 'POD QR',
      badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    },
    {
      id: 'settings',
      label: 'Settings & VAT',
      labelAr: 'الإعدادات والضريبة',
      icon: <Settings className="w-5 h-5" />,
      badge: `${settings.defaultVatRate}%`,
      badgeColor: 'bg-slate-800 text-slate-300 border-slate-700',
    },
  ];

  const handleNavClick = (id: AppPanel) => {
    onSelectPanel(id);
    onCloseMobile();
  };

  const navContent = (
    <div className="flex flex-col h-full bg-slate-900 border-r border-slate-800/80 text-slate-100 select-none">
      
      {/* Sidebar Header Brand */}
      <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-600/20 border border-emerald-500/30 rounded-xl text-emerald-400 shadow-sm">
            <QrCode className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
              <span>Fatoora ZATCA</span>
            </h2>
            <p className="text-[11px] text-slate-400 font-medium">
              Phase 1 & Phase 2 System
            </p>
          </div>
        </div>

        {/* Mobile Close Button */}
        <button
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg"
          aria-label="Close sidebar"
          id="close-sidebar-mobile-btn"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Role / Context Card */}
      <div className="px-4 py-3 bg-slate-950/60 border-b border-slate-800/60 mx-3 my-3 rounded-xl border flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <div>
            <span className="text-xs font-bold text-white block">
              {settings.companyName || 'Al-Riyadh Trading'}
            </span>
            <span className="text-[10px] text-slate-400 block font-mono">
              VAT: {settings.vatNumber || '310123456700003'}
            </span>
          </div>
        </div>
        <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
          Active
        </span>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        <div className="px-3 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          Panels & Operations
        </div>

        {navItems.map((item) => {
          const isActive = activePanel === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-semibold transition-all duration-150 group ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/30 border border-emerald-500/50'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80 border border-transparent'
              }`}
              id={`nav-tab-${item.id}`}
            >
              <div className="flex items-center gap-3">
                <span className={`transition-transform duration-150 group-hover:scale-110 ${
                  isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'
                }`}>
                  {item.icon}
                </span>
                <div className="text-left">
                  <span className="block">{item.label}</span>
                  <span className={`text-[10px] block font-normal opacity-70 ${
                    isActive ? 'text-emerald-100' : 'text-slate-500'
                  }`}>
                    {item.labelAr}
                  </span>
                </div>
              </div>

              {item.badge && (
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                  isActive ? 'bg-emerald-700/80 text-white border-emerald-400/40' : (item.badgeColor || 'bg-slate-800 text-slate-400 border-slate-700')
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Info */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40 space-y-2 text-xs">
        <div className="flex items-center justify-between text-slate-400 text-[11px]">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            ZATCA Compliance
          </span>
          <span className="font-mono text-emerald-400">v2.4.0</span>
        </div>
        <p className="text-[10px] text-slate-500 leading-relaxed">
          Unified Frame Architecture • Responsive Desktop & Mobile Layout
        </p>
      </div>

    </div>
  );

  return (
    <>
      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:block w-64 flex-shrink-0 h-screen sticky top-0 left-0 z-30">
        {navContent}
      </aside>

      {/* Mobile Backdrop Overlay */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 lg:hidden transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* Mobile Slide-over Drawer */}
      <div
        className={`fixed inset-y-0 left-0 w-72 max-w-[80vw] bg-slate-900 z-50 lg:hidden transition-transform duration-300 ease-in-out transform shadow-2xl ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {navContent}
      </div>
    </>
  );
};
