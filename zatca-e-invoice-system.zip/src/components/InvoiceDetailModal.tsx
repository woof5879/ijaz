import React, { useState } from 'react';
import { Invoice } from '../types';
import { formatSAR, formatDate } from '../utils/zatca';
import { QRCodeSVG } from 'qrcode.react';
import {
  X,
  Printer,
  Download,
  CreditCard,
  Edit3,
  ShieldCheck,
  Copy,
  Check,
  FileText,
  Receipt,
  Trash2,
  Loader2,
} from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface InvoiceDetailModalProps {
  invoice: Invoice | null;
  onClose: () => void;
  onOpenPaymentModal: (invoice: Invoice) => void;
  onEditInvoice?: (invoice: Invoice) => void;
  onDeleteInvoice?: (id: string) => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  invoice,
  onClose,
  onOpenPaymentModal,
  onEditInvoice,
  onDeleteInvoice,
}) => {
  const [copiedB64, setCopiedB64] = useState(false);
  const [activeTab, setActiveTab] = useState<'invoice' | 'receipt' | 'technical'>('invoice');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  if (!invoice) return null;

  const handleCopyBase64 = () => {
    navigator.clipboard.writeText(invoice.qrBase64);
    setCopiedB64(true);
    setTimeout(() => setCopiedB64(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    if (!invoice) return;
    setIsGeneratingPDF(true);

    try {
      // Determine which element to download based on tab or default to invoice
      const elementId = activeTab === 'receipt' ? 'zatca-receipt-document' : 'zatca-invoice-document';
      let element = document.getElementById(elementId);

      // If viewing technical tab, default to printing the main invoice document
      if (!element) {
        element = document.getElementById('zatca-invoice-document');
      }

      if (!element) {
        console.error('Printable invoice element not found');
        setIsGeneratingPDF(false);
        return;
      }

      // Render clean canvas
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      const imgWidth = pdfWidth - 20; // 10mm margin each side
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 10;

      pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight - 20;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight + 10;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight - 20;
      }

      const docType = activeTab === 'receipt' ? 'POS_Receipt' : 'Tax_Invoice';
      pdf.save(`ZATCA_${docType}_${invoice.invoiceNumber}.pdf`);
    } catch (err) {
      console.error('Failed to generate invoice PDF:', err);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col my-8 max-h-[90vh]">
        
        {/* Modal Top Toolbar (Screen Only) */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold text-emerald-400 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-md">
              {invoice.invoiceNumber}
            </span>
            <span className="text-xs text-slate-400">
              {invoice.phase} • {invoice.inputMethod}
            </span>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            
            {/* Download PDF Button */}
            <button
              onClick={handleDownloadPDF}
              disabled={isGeneratingPDF}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 rounded-lg transition-colors shadow-sm disabled:opacity-50"
              id="download-pdf-btn"
              title="Save as PDF / Download PDF"
            >
              {isGeneratingPDF ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Download className="w-3.5 h-3.5" />
              )}
              <span>{isGeneratingPDF ? 'Generating PDF...' : 'Download PDF'}</span>
            </button>

            {/* Print Button */}
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
              id="print-invoice-btn"
              title="Print ZATCA Invoice"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            {/* Edit Button */}
            {onEditInvoice && (
              <button
                onClick={() => {
                  const currentInv = invoice;
                  onClose();
                  onEditInvoice(currentInv);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-lg transition-colors"
                id="modal-edit-invoice-btn"
                title="Edit Invoice Details"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            )}

            {/* Payment Button */}
            <button
              onClick={() => onOpenPaymentModal(invoice)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-400 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 rounded-lg transition-colors"
              id="modal-update-payment-btn"
              title="Record Payment"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Payment</span>
            </button>

            {/* Delete Button */}
            {onDeleteInvoice && (
              <button
                onClick={() => {
                  onDeleteInvoice(invoice.id);
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-lg transition-colors"
                id="modal-delete-invoice-btn"
                title="Delete Invoice"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            )}

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg transition-colors ml-1"
              id="close-invoice-modal-btn"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* View Mode Tabs (Screen Only) */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 text-xs font-bold uppercase tracking-wider print:hidden overflow-x-auto">
          <button
            onClick={() => setActiveTab('invoice')}
            className={`px-6 py-3 border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'invoice'
                ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            Standard Tax Invoice (A4)
          </button>

          <button
            onClick={() => setActiveTab('receipt')}
            className={`px-6 py-3 border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'receipt'
                ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Receipt className="w-4 h-4" />
            Thermal POS Receipt (80mm)
          </button>

          <button
            onClick={() => setActiveTab('technical')}
            className={`px-6 py-3 border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'technical'
                ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            ZATCA TLV & Phase 2 Inspector
          </button>
        </div>

        {/* Scrollable Printable Document Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 print:p-0 print:overflow-visible">
          
          {/* TAB 1: STANDARD BILINGUAL ZATCA TAX INVOICE (A4) */}
          {(activeTab === 'invoice' || true) && (
            <div
              id="zatca-invoice-document"
              className={`printable-area bg-white text-slate-900 p-8 rounded-xl shadow-lg border border-slate-200 max-w-3xl mx-auto space-y-6 font-sans print:shadow-none print:border-none print:max-w-none ${
                activeTab !== 'invoice' ? 'hidden print:block' : ''
              }`}
            >
              
              {/* ZATCA Header Section */}
              <div className="flex flex-col sm:flex-row justify-between items-start border-b border-slate-300 pb-6 gap-6">
                <div>
                  <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
                    فاتورة ضريبية مبسطة / Tax Invoice
                  </h1>
                  <p className="text-xs text-slate-600 mt-1 font-semibold">
                    ZATCA Phase 1 & Phase 2 E-Invoice Compliant
                  </p>
                  
                  <div className="mt-3 text-xs space-y-0.5 text-slate-700">
                    <p className="font-bold text-slate-900">{invoice.sellerName}</p>
                    {invoice.sellerNameAr && <p className="font-semibold text-slate-800">{invoice.sellerNameAr}</p>}
                    <p>الرقم الضريبي / VAT No: <strong className="font-mono">{invoice.sellerVatNumber}</strong></p>
                    {invoice.sellerAddress && <p>{invoice.sellerAddress}</p>}
                  </div>
                </div>

                {/* Embedded ZATCA QR Code */}
                <div className="flex flex-col items-center bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <QRCodeSVG
                    value={invoice.qrBase64}
                    size={130}
                    level="M"
                    includeMargin={false}
                  />
                  <span className="text-[9px] font-mono text-slate-500 mt-2">
                    ZATCA QR Tag 1-5 Base64
                  </span>
                </div>
              </div>

              {/* Invoice Meta Summary Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block">رقم الفاتورة / Invoice No:</span>
                  <span className="font-bold font-mono text-slate-900">{invoice.invoiceNumber}</span>
                </div>

                <div>
                  <span className="text-slate-500 block">التاريخ / Issue Date:</span>
                  <span className="font-bold text-slate-900">{formatDate(invoice.issueDate)}</span>
                </div>

                <div>
                  <span className="text-slate-500 block">طريقة الإدخال / Input:</span>
                  <span className="font-bold text-slate-900">{invoice.inputMethod}</span>
                </div>

                <div>
                  <span className="text-slate-500 block">حالة الدفع / Payment:</span>
                  <span className="font-bold text-slate-900">
                    {invoice.paymentStatus === 'Paid'
                      ? '🟢 تم الدفع / Paid'
                      : invoice.paymentStatus === 'Unpaid'
                      ? '🔴 غير مدفوع / Unpaid'
                      : '🟡 مدفوع جزئياً / Partial'}
                  </span>
                </div>
              </div>

              {/* Buyer Info */}
              {invoice.buyerName && (
                <div className="text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-slate-500 block font-semibold">العميل / Buyer Details:</span>
                  <p className="font-bold text-slate-900 mt-0.5">{invoice.buyerName}</p>
                  {invoice.buyerVatNumber && (
                    <p className="text-slate-700 font-mono text-[11px]">
                      VAT No: {invoice.buyerVatNumber}
                    </p>
                  )}
                </div>
              )}

              {/* Line Items Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-900 text-white uppercase text-[10px] tracking-wider">
                      <th className="p-2.5">الوصف / Description</th>
                      <th className="p-2.5 text-center">الكمية / Qty</th>
                      <th className="p-2.5 text-right">سعر الوحدة / Unit</th>
                      <th className="p-2.5 text-right">الخصم / Disc</th>
                      <th className="p-2.5 text-right">الضريبة / VAT</th>
                      <th className="p-2.5 text-right">المجموع / Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {invoice.items.map((item) => (
                      <tr key={item.id}>
                        <td className="p-2.5 font-medium text-slate-900">
                          {item.description}
                          {item.descriptionAr && <div className="text-[10px] text-slate-500">{item.descriptionAr}</div>}
                        </td>
                        <td className="p-2.5 text-center font-mono">{item.quantity}</td>
                        <td className="p-2.5 text-right font-mono">{item.unitPrice.toFixed(2)}</td>
                        <td className="p-2.5 text-right font-mono text-amber-700">
                          {item.discount > 0 ? item.discount.toFixed(2) : '-'}
                        </td>
                        <td className="p-2.5 text-right font-mono text-blue-700">{item.vatAmount.toFixed(2)}</td>
                        <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                          {item.totalAmount.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Calculation Summary Box */}
              <div className="flex flex-col sm:flex-row justify-between items-start pt-4 border-t border-slate-300 gap-6 text-xs">
                
                <div className="space-y-2 text-slate-600 max-w-sm">
                  <p className="text-[11px] leading-relaxed">
                    تعتبر هذه الفاتورة مطابقة لااشتراطات الهيئة العامة للزكاة والدخل والضريبة (زاتكا) في المملكة العربية السعودية.
                  </p>
                  {invoice.zatcaHash && (
                    <div className="font-mono text-[9px] bg-slate-100 p-2 rounded border border-slate-200 break-all text-slate-500">
                      Phase 2 Hash Digest: {invoice.zatcaHash}
                    </div>
                  )}
                </div>

                <div className="w-full sm:w-64 space-y-1.5 font-mono text-right bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div className="flex justify-between text-slate-600">
                    <span>المجموع / Subtotal:</span>
                    <span>{formatSAR(invoice.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-amber-700 font-semibold">
                    <span>الخصم / Total Discount:</span>
                    <span>-{formatSAR(invoice.discount)}</span>
                  </div>
                  <div className="flex justify-between text-slate-800 font-medium">
                    <span>المبلغ الخاضع للضريبة / Taxable:</span>
                    <span>{formatSAR(invoice.taxableAmount)}</span>
                  </div>
                  <div className="flex justify-between text-blue-700 font-bold">
                    <span>ضريبة القيمة المضافة / VAT ({invoice.vatRate}%):</span>
                    <span>+{formatSAR(invoice.vatAmount)}</span>
                  </div>
                  <div className="flex justify-between text-slate-900 font-black text-sm pt-2 border-t border-slate-300">
                    <span>المبلغ الإجمالي / Total:</span>
                    <span className="text-emerald-700">{formatSAR(invoice.totalAmount)}</span>
                  </div>

                  {invoice.paidAmount > 0 && (
                    <div className="flex justify-between text-emerald-800 text-[11px] pt-1">
                      <span>المدفوع / Paid Amount:</span>
                      <span>{formatSAR(invoice.paidAmount)}</span>
                    </div>
                  )}

                  {invoice.remainingAmount > 0 && (
                    <div className="flex justify-between text-rose-700 text-[11px] font-bold">
                      <span>المتبقي / Outstanding:</span>
                      <span>{formatSAR(invoice.remainingAmount)}</span>
                    </div>
                  )}
                </div>

              </div>

            </div>
          )}

          {/* TAB 2: THERMAL POS RECEIPT VIEW */}
          {activeTab === 'receipt' && (
            <div
              id="zatca-receipt-document"
              className="printable-area bg-amber-50/90 text-slate-900 p-6 rounded-xl shadow-lg border border-amber-200 max-w-xs mx-auto font-mono text-xs space-y-4"
            >
              <div className="text-center space-y-1 border-b border-dashed border-slate-400 pb-3">
                <h2 className="font-black text-sm uppercase">{invoice.sellerName}</h2>
                <p className="text-[10px]">VAT #: {invoice.sellerVatNumber}</p>
                <p className="text-[10px]">ZATCA POS E-RECEIPT</p>
              </div>

              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>INV #:</span>
                  <span className="font-bold">{invoice.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>DATE:</span>
                  <span>{formatDate(invoice.issueDate)} {invoice.issueTime}</span>
                </div>
              </div>

              <div className="border-t border-b border-dashed border-slate-400 py-2 space-y-1.5">
                {invoice.items.map((item) => (
                  <div key={item.id} className="flex justify-between text-[11px]">
                    <span className="truncate max-w-[140px]">{item.quantity}x {item.description}</span>
                    <span>{item.totalAmount.toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-right text-[11px]">
                <div className="flex justify-between">
                  <span>SUBTOTAL:</span>
                  <span>{invoice.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-amber-800">
                  <span>DISCOUNT:</span>
                  <span>-{invoice.discount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-blue-800 font-semibold">
                  <span>VAT ({invoice.vatRate}%):</span>
                  <span>+{invoice.vatAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-black text-sm border-t border-slate-400 pt-1">
                  <span>TOTAL SAR:</span>
                  <span>{invoice.totalAmount.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-center pt-2 border-t border-dashed border-slate-400">
                <QRCodeSVG value={invoice.qrBase64} size={110} />
              </div>

              <p className="text-[9px] text-center text-slate-500 uppercase tracking-tight">
                Thank you for your business!
              </p>
            </div>
          )}

          {/* TAB 3: TECHNICAL TLV & PHASE 2 INSPECTOR */}
          {activeTab === 'technical' && (
            <div className="space-y-6">
              
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4" />
                    ZATCA TLV Base64 Code
                  </h4>
                  <button
                    onClick={handleCopyBase64}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors"
                  >
                    {copiedB64 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedB64 ? 'Copied!' : 'Copy Base64'}</span>
                  </button>
                </div>

                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 font-mono text-xs text-emerald-300 break-all">
                  {invoice.qrBase64}
                </div>
              </div>

              {/* Tag Breakdown */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  ZATCA Standard Tag-Length-Value Breakdown
                </h4>

                <div className="space-y-2 text-xs">
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 1 (Seller Name)</span>
                      <span className="font-bold text-white">{invoice.sellerName}</span>
                    </div>
                    <span className="font-mono text-slate-500">Length: {invoice.sellerName.length}</span>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 2 (Seller VAT Number)</span>
                      <span className="font-mono font-bold text-blue-400">{invoice.sellerVatNumber}</span>
                    </div>
                    <span className="font-mono text-slate-500">Length: 15</span>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 3 (Timestamp ISO 8601)</span>
                      <span className="font-mono text-slate-300">{invoice.issueDate}T{invoice.issueTime}:00Z</span>
                    </div>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 4 (Total Invoice Amount)</span>
                      <span className="font-mono font-bold text-emerald-400">{invoice.totalAmount.toFixed(2)} SAR</span>
                    </div>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 5 (VAT Amount)</span>
                      <span className="font-mono font-bold text-amber-400">{invoice.vatAmount.toFixed(2)} SAR</span>
                    </div>
                  </div>

                  {invoice.zatcaHash && (
                    <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-semibold">Tag 6 (Phase 2 ECDSA Cryptographic Hash Digest)</span>
                      <span className="font-mono text-xs text-purple-300 break-all">{invoice.zatcaHash}</span>
                    </div>
                  )}
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Bottom Sticky Footer (Screen Only) */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between print:hidden">
          <div className="text-xs text-slate-400">
            ZATCA Document ID: <span className="font-mono text-slate-200">{invoice.id}</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors flex items-center gap-1.5"
            id="modal-bottom-close-btn"
          >
            <X className="w-4 h-4" />
            <span>Close Preview</span>
          </button>
        </div>

      </div>
    </div>
  );
};
