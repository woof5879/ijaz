import React from 'react';
import { DashboardMetrics, FilterState, Invoice } from '../../types';
import { Dashboard } from '../Dashboard';
import { InvoiceTable } from '../InvoiceTable';

interface ZatcaInvoicesPanelProps {
  metrics: DashboardMetrics;
  filteredInvoices: Invoice[];
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  onResetFilters: () => void;
  isFilteredActive: boolean;
  onViewInvoice: (invoice: Invoice) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onRecordPayment: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
}

export const ZatcaInvoicesPanel: React.FC<ZatcaInvoicesPanelProps> = ({
  metrics,
  filteredInvoices,
  filters,
  onFilterChange,
  onResetFilters,
  isFilteredActive,
  onViewInvoice,
  onEditInvoice,
  onRecordPayment,
  onDeleteInvoice,
}) => {
  return (
    <div className="space-y-8">
      {/* Executive Admin Dashboard Metrics */}
      <Dashboard
        metrics={metrics}
        isFiltered={isFilteredActive}
        onClearFilters={onResetFilters}
      />

      {/* ZATCA Invoice History Table with Filters */}
      <InvoiceTable
        invoices={filteredInvoices}
        filters={filters}
        onFilterChange={onFilterChange}
        onResetFilters={onResetFilters}
        onViewInvoice={onViewInvoice}
        onEditInvoice={onEditInvoice}
        onRecordPayment={onRecordPayment}
        onDeleteInvoice={onDeleteInvoice}
      />
    </div>
  );
};
