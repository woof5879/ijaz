import React, { useState } from 'react';
import { Settings, Building2, ShieldCheck, DollarSign, Save, RotateCcw, Check, Sparkles } from 'lucide-react';
import { AppSettings, InvoicePhase } from '../../types';

interface SettingsPanelProps {
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
  onResetData: () => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  settings,
  onSaveSettings,
  onResetData,
}) => {
  const [formData, setFormData] = useState<AppSettings>(settings);
  const [isSaved, setIsSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-emerald-500/20 border border-emerald-500/30 rounded-lg text-emerald-400">
                <Settings className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-extrabold text-white">VAT & Business Entity Settings</h2>
            </div>
            <p className="text-xs text-slate-300">
              Configure bilingual seller profile, 15% KSA VAT rules, and default ZATCA Phase 1 / Phase 2 modes.
            </p>
          </div>

          <button
            onClick={onResetData}
            className="px-3.5 py-2 text-xs font-semibold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-xl transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Sample Data
          </button>
        </div>
      </div>

      {isSaved && (
        <div className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 p-4 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <Check className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <span>Configuration saved successfully! All newly generated ZATCA invoices will apply these settings.</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md space-y-6">
        
        {/* Company Profile Section */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
            <Building2 className="w-4 h-4 text-emerald-400" />
            Business Entity Information (Bilingual English / Arabic)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Company Name (English)</label>
              <input
                type="text"
                required
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                className="w-full bg-slate-950 text-white p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">اسم المنشأة (بالعربية)</label>
              <input
                type="text"
                required
                value={formData.companyNameAr}
                onChange={(e) => setFormData({ ...formData, companyNameAr: e.target.value })}
                className="w-full bg-slate-950 text-white p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none dir-rtl"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                ZATCA VAT Registration Number (15 Digits)
              </label>
              <input
                type="text"
                required
                maxLength={15}
                pattern="\d{15}"
                value={formData.vatNumber}
                onChange={(e) => setFormData({ ...formData, vatNumber: e.target.value })}
                className="w-full bg-slate-950 text-emerald-400 font-mono font-bold p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Registered Address / Location</label>
              <input
                type="text"
                required
                value={formData.companyAddress}
                onChange={(e) => setFormData({ ...formData, companyAddress: e.target.value })}
                className="w-full bg-slate-950 text-white p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* VAT & Tax Rate Rules */}
        <div className="space-y-4 pt-2 border-t border-slate-800">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            Tax Rates & Currency Configuration
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Default KSA VAT Rate (%)</label>
              <input
                type="number"
                step="0.01"
                required
                value={formData.defaultVatRate}
                onChange={(e) => setFormData({ ...formData, defaultVatRate: Number(e.target.value) })}
                className="w-full bg-slate-950 text-white font-mono p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Currency Symbol</label>
              <input
                type="text"
                required
                value={formData.currencySymbol}
                onChange={(e) => setFormData({ ...formData, currencySymbol: e.target.value })}
                className="w-full bg-slate-950 text-white font-mono p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">ZATCA Phase Mode</label>
              <select
                value={formData.defaultPhase}
                onChange={(e) => setFormData({ ...formData, defaultPhase: e.target.value as InvoicePhase })}
                className="w-full bg-slate-950 text-white p-2.5 rounded-xl border border-slate-700 focus:border-emerald-500 outline-none"
              >
                <option value="Phase 1 (Simplified)">Phase 1 (Simplified E-Invoice)</option>
                <option value="Phase 2 (Integration/Standard)">Phase 2 (Integration & ECDSA Hash)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end pt-4 border-t border-slate-800">
          <button
            type="submit"
            className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-lg transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save Configuration
          </button>
        </div>

      </form>

    </div>
  );
};
