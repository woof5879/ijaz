import React, { useState } from 'react';
import {
  Navigation,
  QrCode,
  CheckCircle,
  Clock,
  MapPin,
  PhoneCall,
  FileText,
  User,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { DriverTrip, Invoice } from '../../types';
import { formatSAR } from '../../utils/zatca';

interface DriverPanelProps {
  invoices: Invoice[];
  onViewInvoice: (invoice: Invoice) => void;
  onOpenQRInputModal: () => void;
}

export const DriverPanel: React.FC<DriverPanelProps> = ({
  invoices,
  onViewInvoice,
  onOpenQRInputModal,
}) => {
  const [trips, setTrips] = useState<DriverTrip[]>([
    {
      id: 'trip-1',
      tripNumber: 'TRIP-401',
      route: 'Riyadh Hub → Olaya Commercial District',
      customerName: 'Al-Madina Retail Superstores',
      deliveryAddress: 'Building 48, King Fahd Road, Riyadh 12211',
      invoiceNumber: invoices[0]?.invoiceNumber || 'INV-1001',
      invoiceAmount: invoices[0]?.totalAmount || 1437.5,
      status: 'En Route',
      podStatus: 'Pending QR',
      scheduledTime: '10:30 AM',
    },
    {
      id: 'trip-2',
      tripNumber: 'TRIP-402',
      route: 'Riyadh Hub → Sulaimaniyah Industrial Yard',
      customerName: 'Gulf Construction Materials Co.',
      deliveryAddress: 'Gate 12, Logistics Sector, Riyadh 13244',
      invoiceNumber: invoices[1]?.invoiceNumber || 'INV-1002',
      invoiceAmount: invoices[1]?.totalAmount || 2875.0,
      status: 'Arrived',
      podStatus: 'Verified',
      scheduledTime: '01:15 PM',
    },
    {
      id: 'trip-3',
      tripNumber: 'TRIP-403',
      route: 'Riyadh Hub → Malaz Distribution Warehouse',
      customerName: 'SABIC Supply Network Partner',
      deliveryAddress: 'Block 7, Airport Highway, Riyadh 11564',
      invoiceNumber: invoices[2]?.invoiceNumber || 'INV-1003',
      invoiceAmount: invoices[2]?.totalAmount || 575.0,
      status: 'Completed',
      podStatus: 'Signed',
      scheduledTime: '04:00 PM',
    },
  ]);

  const [activeTab, setActiveTab] = useState<'trips' | 'scanner'>('trips');
  const [scannedMessage, setScannedMessage] = useState('');

  const handleUpdateTripStatus = (id: string, newStatus: DriverTrip['status']) => {
    setTrips(
      trips.map((t) => {
        if (t.id === id) {
          const pod = newStatus === 'Completed' ? 'Verified' : t.podStatus;
          return { ...t, status: newStatus, podStatus: pod };
        }
        return t;
      })
    );
  };

  const handleSimulateScanPOD = (trip: DriverTrip) => {
    handleUpdateTripStatus(trip.id, 'Completed');
    setScannedMessage(`✅ Proof of Delivery Verified for Invoice ${trip.invoiceNumber}! ZATCA QR verified.`);
    setTimeout(() => setScannedMessage(''), 4000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Driver Mobile Banner */}
      <div className="bg-gradient-to-r from-amber-900/40 via-slate-900 to-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-500/20 border border-amber-500/30 rounded-lg text-amber-400">
                <Navigation className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-extrabold text-white">Driver Mobile Delivery & POD Interface</h2>
            </div>
            <p className="text-xs text-slate-300">
              Mobile driver workflow for verifying customer ZATCA QR receipts and confirming proof of delivery on site.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenQRInputModal}
              className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 rounded-xl transition-all shadow-md flex items-center gap-1.5"
            >
              <QrCode className="w-4 h-4" />
              <span>Scan Customer QR</span>
            </button>
          </div>
        </div>
      </div>

      {scannedMessage && (
        <div className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 p-4 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <span>{scannedMessage}</span>
        </div>
      )}

      {/* Driver Assigned Trips Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" /> Assigned Delivery Route Schedule
          </h3>
          <span className="text-xs text-slate-400 font-mono bg-slate-900 px-2.5 py-1 rounded-md border border-slate-800">
            {trips.length} Destinations Today
          </span>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {trips.map((trip) => {
            const linkedInv = invoices.find((i) => i.invoiceNumber === trip.invoiceNumber);

            return (
              <div
                key={trip.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md hover:border-slate-700 transition-all space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-md">
                      {trip.tripNumber}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      Scheduled: {trip.scheduledTime}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-full border ${
                        trip.status === 'Completed'
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : trip.status === 'Arrived'
                          ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      }`}
                    >
                      {trip.status}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <User className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <span className="text-slate-400 text-[11px] block">Customer / Recipient</span>
                        <strong className="text-white text-sm block">{trip.customerName}</strong>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <span className="text-slate-400 text-[11px] block">Destination Address</span>
                        <p className="text-slate-300 font-medium">{trip.deliveryAddress}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 text-[11px]">Linked ZATCA Tax Invoice</span>
                      <span className="font-mono font-bold text-emerald-400">{trip.invoiceNumber}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 text-[11px]">Invoice Total SAR</span>
                      <span className="font-mono font-extrabold text-white">{formatSAR(trip.invoiceAmount)}</span>
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                      <span className="text-slate-400 text-[11px]">Proof of Delivery (POD)</span>
                      <span className="text-xs font-semibold text-amber-300">{trip.podStatus}</span>
                    </div>
                  </div>
                </div>

                {/* Driver Action Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center gap-2">
                    {linkedInv && (
                      <button
                        onClick={() => onViewInvoice(linkedInv)}
                        className="px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg flex items-center gap-1.5 transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5 text-emerald-400" />
                        View Invoice
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleUpdateTripStatus(trip.id, 'Arrived')}
                      className="px-3 py-1.5 text-xs font-semibold text-blue-300 bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/30 rounded-lg"
                    >
                      Mark Arrived
                    </button>

                    <button
                      onClick={() => handleSimulateScanPOD(trip)}
                      className="px-4 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow flex items-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      Verify POD QR
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
