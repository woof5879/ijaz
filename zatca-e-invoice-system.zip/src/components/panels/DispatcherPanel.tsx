import React, { useState } from 'react';
import {
  Truck,
  Plus,
  MapPin,
  Calendar,
  UserCheck,
  FileCheck2,
  PackageCheck,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowRight,
} from 'lucide-react';
import { DispatchWaybill, Invoice } from '../../types';
import { formatSAR } from '../../utils/zatca';

interface DispatcherPanelProps {
  invoices: Invoice[];
  onViewInvoice: (invoice: Invoice) => void;
  onOpenQRInputModal: () => void;
}

export const DispatcherPanel: React.FC<DispatcherPanelProps> = ({
  invoices,
  onViewInvoice,
  onOpenQRInputModal,
}) => {
  const [waybills, setWaybills] = useState<DispatchWaybill[]>([
    {
      id: 'wb-1',
      waybillNumber: 'WB-9012',
      originCity: 'Riyadh Central Hub',
      destinationCity: 'Jeddah Commercial Port',
      assignedDriver: 'Tariq Al-Mansoor',
      truckPlate: 'LMN-4821',
      invoiceNumber: invoices[0]?.invoiceNumber || 'INV-1001',
      totalWeightKg: 1450,
      status: 'In Transit',
      estimatedDelivery: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      dispatchDate: new Date().toISOString().split('T')[0],
    },
    {
      id: 'wb-2',
      waybillNumber: 'WB-9013',
      originCity: 'Dammam Industrial City',
      destinationCity: 'Khobar Logistics Park',
      assignedDriver: 'Fahad Al-Otaibi',
      truckPlate: 'KSA-7789',
      invoiceNumber: invoices[1]?.invoiceNumber || 'INV-1002',
      totalWeightKg: 820,
      status: 'Delivered',
      estimatedDelivery: new Date().toISOString().split('T')[0],
      dispatchDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    },
    {
      id: 'wb-3',
      waybillNumber: 'WB-9014',
      originCity: 'Riyadh Dry Port',
      destinationCity: 'Madinah Cargo Center',
      assignedDriver: 'Sami Abdulaziz',
      truckPlate: 'RHD-1120',
      invoiceNumber: invoices[2]?.invoiceNumber || 'INV-1003',
      totalWeightKg: 3200,
      status: 'Pending',
      estimatedDelivery: new Date(Date.now() + 172800000).toISOString().split('T')[0],
      dispatchDate: new Date().toISOString().split('T')[0],
    },
  ]);

  const [newWaybill, setNewWaybill] = useState({
    originCity: 'Riyadh Logistics Park',
    destinationCity: 'Jeddah Warehouse',
    assignedDriver: 'Tariq Al-Mansoor',
    truckPlate: 'LMN-4821',
    invoiceNumber: invoices[0]?.invoiceNumber || 'INV-1001',
    totalWeightKg: 1200,
  });

  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddWaybill = (e: React.FormEvent) => {
    e.preventDefault();
    const wb: DispatchWaybill = {
      id: 'wb-' + Date.now(),
      waybillNumber: `WB-${Math.floor(9000 + Math.random() * 999)}`,
      originCity: newWaybill.originCity,
      destinationCity: newWaybill.destinationCity,
      assignedDriver: newWaybill.assignedDriver,
      truckPlate: newWaybill.truckPlate,
      invoiceNumber: newWaybill.invoiceNumber,
      totalWeightKg: Number(newWaybill.totalWeightKg),
      status: 'Pending',
      estimatedDelivery: new Date(Date.now() + 86400000).toISOString().split('T')[0],
      dispatchDate: new Date().toISOString().split('T')[0],
    };

    setWaybills([wb, ...waybills]);
    setShowAddForm(false);
  };

  const handleUpdateStatus = (id: string, newStatus: DispatchWaybill['status']) => {
    setWaybills(waybills.map((w) => (w.id === id ? { ...w, status: newStatus } : w)));
  };

  const getStatusBadge = (status: DispatchWaybill['status']) => {
    switch (status) {
      case 'In Transit':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30 font-semibold">
            <Clock className="w-3 h-3 animate-spin" /> In Transit
          </span>
        );
      case 'Delivered':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-semibold">
            <CheckCircle2 className="w-3 h-3" /> Delivered
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 font-semibold">
            <AlertTriangle className="w-3 h-3" /> Pending Dispatch
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-400 border border-slate-700 font-semibold">
            Cancelled
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Dispatcher Banner */}
      <div className="bg-gradient-to-r from-blue-900/40 via-slate-900 to-slate-900 border border-blue-500/30 rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-blue-500/20 border border-blue-500/30 rounded-lg text-blue-400">
                <Truck className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-extrabold text-white">Dispatcher Fleet & Cargo Controller</h2>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Assign drivers, attach ZATCA Tax Invoices to waybills, and monitor cargo movement across Saudi Arabia in real time.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-all shadow-md flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>{showAddForm ? 'Cancel Form' : 'Issue New Waybill'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Add Waybill Modal Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddWaybill}
          className="bg-slate-900 border border-blue-500/40 p-5 rounded-2xl shadow-xl space-y-4 animate-in fade-in"
        >
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
            <Truck className="w-4 h-4 text-blue-400" /> Issue Fleet Dispatch Waybill
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Origin City / Hub</label>
              <input
                type="text"
                required
                value={newWaybill.originCity}
                onChange={(e) => setNewWaybill({ ...newWaybill, originCity: e.target.value })}
                className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Destination City</label>
              <input
                type="text"
                required
                value={newWaybill.destinationCity}
                onChange={(e) => setNewWaybill({ ...newWaybill, destinationCity: e.target.value })}
                className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Assigned Driver</label>
              <select
                value={newWaybill.assignedDriver}
                onChange={(e) => setNewWaybill({ ...newWaybill, assignedDriver: e.target.value })}
                className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700"
              >
                <option value="Tariq Al-Mansoor">Tariq Al-Mansoor</option>
                <option value="Fahad Al-Otaibi">Fahad Al-Otaibi</option>
                <option value="Sami Abdulaziz">Sami Abdulaziz</option>
                <option value="Mohammed Al-Ghamdi">Mohammed Al-Ghamdi</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Truck License Plate</label>
              <input
                type="text"
                required
                value={newWaybill.truckPlate}
                onChange={(e) => setNewWaybill({ ...newWaybill, truckPlate: e.target.value })}
                className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Linked ZATCA Invoice</label>
              <select
                value={newWaybill.invoiceNumber}
                onChange={(e) => setNewWaybill({ ...newWaybill, invoiceNumber: e.target.value })}
                className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700 font-mono"
              >
                {invoices.map((inv) => (
                  <option key={inv.id} value={inv.invoiceNumber}>
                    {inv.invoiceNumber} - {inv.sellerName} ({formatSAR(inv.totalAmount)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Cargo Weight (KG)</label>
              <input
                type="number"
                required
                value={newWaybill.totalWeightKg}
                onChange={(e) => setNewWaybill({ ...newWaybill, totalWeightKg: Number(e.target.value) })}
                className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-400 bg-slate-800 rounded-lg hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow"
            >
              Confirm Dispatch
            </button>
          </div>
        </form>
      )}

      {/* Dispatch Waybills Table Wrapper */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md space-y-3 p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <PackageCheck className="w-5 h-5 text-blue-400" />
            <h3 className="text-base font-bold text-white">Active Dispatch Waybills & Freight Cargo</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono bg-slate-950 px-3 py-1 rounded-full border border-slate-800">
            {waybills.length} Active Shipments
          </span>
        </div>

        {/* Scrollable Container for Table */}
        <div className="overflow-x-auto w-full border border-slate-800 rounded-lg">
          <table className="w-full text-xs text-left text-slate-200">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="px-4 py-3 font-semibold">Waybill #</th>
                <th className="px-4 py-3 font-semibold">Route (Origin → Dest)</th>
                <th className="px-4 py-3 font-semibold">Driver & Plate</th>
                <th className="px-4 py-3 font-semibold">Linked Invoice</th>
                <th className="px-4 py-3 font-semibold">Cargo Weight</th>
                <th className="px-4 py-3 font-semibold text-center">Dispatch Status</th>
                <th className="px-4 py-3 font-semibold text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {waybills.map((wb) => {
                const linkedInv = invoices.find((i) => i.invoiceNumber === wb.invoiceNumber);
                return (
                  <tr key={wb.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3 font-mono font-bold text-blue-400 whitespace-nowrap">
                      {wb.waybillNumber}
                    </td>
                    <td className="px-4 py-3 text-slate-200 whitespace-nowrap">
                      <span className="font-semibold">{wb.originCity}</span>
                      <ArrowRight className="w-3 h-3 inline-block mx-1.5 text-blue-400" />
                      <span className="font-semibold text-emerald-400">{wb.destinationCity}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-300 whitespace-nowrap">
                      <div className="font-semibold text-white">{wb.assignedDriver}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{wb.truckPlate}</div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      {linkedInv ? (
                        <button
                          onClick={() => onViewInvoice(linkedInv)}
                          className="font-mono text-emerald-400 hover:underline flex items-center gap-1 font-bold"
                        >
                          <FileCheck2 className="w-3.5 h-3.5" />
                          {wb.invoiceNumber} ({formatSAR(linkedInv.totalAmount)})
                        </button>
                      ) : (
                        <span className="font-mono text-slate-500">{wb.invoiceNumber}</span>
                      )}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-300 whitespace-nowrap">
                      {wb.totalWeightKg.toLocaleString()} KG
                    </td>
                    <td className="px-4 py-3 text-center whitespace-nowrap">
                      {getStatusBadge(wb.status)}
                    </td>
                    <td className="px-4 py-3 text-center whitespace-nowrap">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => handleUpdateStatus(wb.id, 'In Transit')}
                          className="px-2 py-1 text-[10px] bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 rounded font-semibold border border-blue-500/30"
                        >
                          In Transit
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(wb.id, 'Delivered')}
                          className="px-2 py-1 text-[10px] bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 rounded font-semibold border border-emerald-500/30"
                        >
                          Delivered
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
