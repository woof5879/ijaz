import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Activity,
  Users,
  Database,
  FileCheck,
  AlertCircle,
  Clock,
  Terminal,
  RefreshCw,
} from 'lucide-react';
import { AppSettings, DashboardMetrics, Invoice, AuditLogEntry } from '../../types';
import { formatSAR } from '../../utils/zatca';

interface AdminPanelProps {
  metrics: DashboardMetrics;
  invoices: Invoice[];
  settings: AppSettings;
  onResetData: () => void;
  onOpenQRInputModal: () => void;
  onOpenSettingsModal: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  metrics,
  invoices,
  settings,
  onResetData,
  onOpenQRInputModal,
  onOpenSettingsModal,
}) => {
  const [logs] = useState<AuditLogEntry[]>([
    {
      id: 'log-1',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userRole: 'Admin',
      action: 'ZATCA Compliance Validation',
      details: 'Validated Phase 1 & 2 TLV tags & ECDSA public keys for active company profile.',
      ipAddress: '192.168.1.104',
    },
    {
      id: 'log-2',
      timestamp: new Date(Date.now() - 3600000).toISOString().replace('T', ' ').substring(0, 19),
      userRole: 'System',
      action: 'Auto Storage Synchronization',
      details: `Saved ${invoices.length} invoices to encrypted local storage database.`,
      ipAddress: '127.0.0.1',
    },
    {
      id: 'log-3',
      timestamp: new Date(Date.now() - 7200000).toISOString().replace('T', ' ').substring(0, 19),
      userRole: 'Dispatcher',
      action: 'Waybill Issued & Linked',
      details: 'Linked Tax Invoice INV-1002 to Logistics Dispatch Waybill WB-5012.',
      ipAddress: '192.168.1.112',
    },
    {
      id: 'log-4',
      timestamp: new Date(Date.now() - 10800000).toISOString().replace('T', ' ').substring(0, 19),
      userRole: 'Driver',
      action: 'POD QR Scan Complete',
      details: 'Customer verified delivery invoice with ZATCA QR Code.',
      ipAddress: '10.0.4.15',
    },
  ]);

  const phase2ClearedCount = invoices.filter((i) => i.isClearedByZATCA || i.phase.includes('Phase 2')).length;
  const clearanceRate = invoices.length > 0 ? Math.round((phase2ClearedCount / invoices.length) * 100) : 100;

  return (
    <div className="space-y-6">
      
      {/* Executive Overview Banner */}
      <div className="bg-gradient-to-r from-purple-900/40 via-slate-900 to-slate-900 border border-purple-500/30 rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-purple-500/20 border border-purple-500/30 rounded-lg text-purple-400">
                <ShieldAlert className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-extrabold text-white">Executive Compliance & Audit Dashboard</h2>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Real-time monitoring of ZATCA Phase 1 & 2 tax compliance, audit log telemetry, system health, and VAT calculations for <strong className="text-white">{settings.companyName}</strong>.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={onOpenSettingsModal}
              className="px-3.5 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors"
            >
              System Config
            </button>
            <button
              onClick={onResetData}
              className="px-3.5 py-2 text-xs font-semibold text-purple-300 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reset Samples
            </button>
          </div>
        </div>
      </div>

      {/* Admin KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">ZATCA Clearance Rate</span>
            <span className="p-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg">
              <FileCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-white font-mono">{clearanceRate}%</div>
          <p className="text-[11px] text-slate-400">
            {phase2ClearedCount} of {invoices.length} invoices cleared with Phase 2 hash
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total VAT Collected</span>
            <span className="p-2 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-lg">
              <Activity className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-blue-400 font-mono">
            {formatSAR(metrics.totalVatAmount)}
          </div>
          <p className="text-[11px] text-slate-400">Standard 15% KSA Tax Rate</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Gross Revenue</span>
            <span className="p-2 bg-purple-500/10 text-purple-400 border border-purple-500/20 rounded-lg">
              <Database className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">
            {formatSAR(metrics.totalInvoiceAmount)}
          </div>
          <p className="text-[11px] text-slate-400">{metrics.totalInvoicesCount} total registered invoices</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Outstanding Receivable</span>
            <span className="p-2 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-lg">
              <AlertCircle className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-rose-400 font-mono">
            {formatSAR(metrics.outstandingAmount)}
          </div>
          <p className="text-[11px] text-slate-400">{metrics.unpaidInvoicesCount} pending unpaid invoices</p>
        </div>

      </div>

      {/* System Audit Telemetry Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md space-y-3 p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-purple-400" />
            <h3 className="text-base font-bold text-white">System Security & Audit Telemetry</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono bg-slate-950 px-3 py-1 rounded-full border border-slate-800">
            Encrypted Log Engine
          </span>
        </div>

        {/* Scrollable Container for Table */}
        <div className="overflow-x-auto w-full border border-slate-800 rounded-lg">
          <table className="w-full text-xs text-left text-slate-200">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="px-4 py-3 font-semibold">Timestamp</th>
                <th className="px-4 py-3 font-semibold">User Role</th>
                <th className="px-4 py-3 font-semibold">Action Event</th>
                <th className="px-4 py-3 font-semibold">Audit Details</th>
                <th className="px-4 py-3 font-semibold text-right">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono text-[11px]">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="px-4 py-3 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-bold">
                      {log.userRole}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-semibold text-white whitespace-nowrap">{log.action}</td>
                  <td className="px-4 py-3 text-slate-300 font-sans max-w-md">{log.details}</td>
                  <td className="px-4 py-3 text-right text-slate-500 whitespace-nowrap">{log.ipAddress || '127.0.0.1'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
