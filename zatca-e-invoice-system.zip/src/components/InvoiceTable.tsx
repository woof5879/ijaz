import React from 'react';
import { Invoice, FilterState, PaymentStatus, InputMethod } from '../types';
import { formatSAR, formatDate } from '../utils/zatca';
import { Search, Calendar, Filter, Eye, Edit3, CreditCard, Trash2, QrCode, ArrowUpDown, FileSpreadsheet } from 'lucide-react';

interface InvoiceTableProps {
  invoices: Invoice[];
  filters: FilterState;
  onFilterChange: (newFilters: FilterState) => void;
  onResetFilters: () => void;
  onViewInvoice: (invoice: Invoice) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onRecordPayment: (invoice: Invoice) => void;
  onDeleteInvoice: (id: string) => void;
}

export const InvoiceTable: React.FC<InvoiceTableProps> = ({
  invoices,
  filters,
  onFilterChange,
  onResetFilters,
  onViewInvoice,
  onEditInvoice,
  onRecordPayment,
  onDeleteInvoice,
}) => {

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, searchQuery: e.target.value });
  };

  const handleFromDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, fromDate: e.target.value });
  };

  const handleToDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, toDate: e.target.value });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, paymentStatus: e.target.value as any });
  };

  const handleInputMethodChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, inputMethod: e.target.value as any });
  };

  const getStatusBadge = (status: PaymentStatus) => {
    switch (status) {
      case 'Paid':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            🟢 Paid
          </span>
        );
      case 'Unpaid':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30">
            🔴 Unpaid
          </span>
        );
      case 'Partially Paid':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30">
            🟡 Partially Paid
          </span>
        );
    }
  };

  const getInputMethodBadge = (method: InputMethod) => {
    switch (method) {
      case 'QR Scan':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-medium">
            <QrCode className="w-3 h-3" />
            QR Scan
          </span>
        );
      case 'Manual':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-medium">
            Manual
          </span>
        );
      case 'Base64 Paste':
        return (
          <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-medium">
            Base64 Paste
          </span>
        );
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-md overflow-hidden space-y-4">
      
      {/* Filters Header Section */}
      <div className="p-4 sm:p-5 bg-slate-950/60 border-b border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">📋 ZATCA Invoice History</h3>
            <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono">
              {invoices.length} {invoices.length === 1 ? 'Record' : 'Records'}
            </span>
          </div>

          <button
            onClick={onResetFilters}
            className="text-xs text-slate-400 hover:text-slate-200 transition-colors flex items-center gap-1"
            id="reset-all-filters-btn"
          >
            Clear All Filters
          </button>
        </div>

        {/* Filter Form Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          
          {/* Search Box */}
          <div className="relative">
            <label className="block text-[11px] font-semibold text-slate-400 mb-1 uppercase tracking-wider">
              Search Invoice / Party
            </label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                value={filters.searchQuery}
                onChange={handleSearchChange}
                placeholder="INV-1001, Seller, VAT..."
                className="w-full bg-slate-900 text-white pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                id="search-input"
              />
            </div>
          </div>

          {/* From Date */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1 uppercase tracking-wider">
              From Date
            </label>
            <input
              type="date"
              value={filters.fromDate}
              onChange={handleFromDateChange}
              className="w-full bg-slate-900 text-white px-3 py-1.5 text-xs rounded-lg border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
              id="from-date-input"
            />
          </div>

          {/* To Date */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1 uppercase tracking-wider">
              To Date
            </label>
            <input
              type="date"
              value={filters.toDate}
              onChange={handleToDateChange}
              className="w-full bg-slate-900 text-white px-3 py-1.5 text-xs rounded-lg border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
              id="to-date-input"
            />
          </div>

          {/* Payment Status Dropdown */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1 uppercase tracking-wider">
              Payment Status
            </label>
            <select
              value={filters.paymentStatus}
              onChange={handleStatusChange}
              className="w-full bg-slate-900 text-white px-3 py-1.5 text-xs rounded-lg border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
              id="status-filter-select"
            >
              <option value="All">All Statuses</option>
              <option value="Paid">🟢 Paid</option>
              <option value="Unpaid">🔴 Unpaid</option>
              <option value="Partially Paid">🟡 Partially Paid</option>
            </select>
          </div>

          {/* Input Method Dropdown */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 mb-1 uppercase tracking-wider">
              Input Method
            </label>
            <select
              value={filters.inputMethod}
              onChange={handleInputMethodChange}
              className="w-full bg-slate-900 text-white px-3 py-1.5 text-xs rounded-lg border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
              id="input-method-filter-select"
            >
              <option value="All">All Input Methods</option>
              <option value="QR Scan">QR Scan</option>
              <option value="Manual">Manual</option>
              <option value="Base64 Paste">Base64 Paste</option>
            </select>
          </div>

        </div>
      </div>

      {/* History Table */}
      <div className="overflow-x-auto">
        {invoices.length === 0 ? (
          <div className="text-center py-12 px-4 space-y-3">
            <FileSpreadsheet className="w-12 h-12 text-slate-600 mx-auto" />
            <h4 className="text-sm font-semibold text-slate-300">No ZATCA invoices found matching your filters</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Try adjusting your date range or filter criteria, or scan/create a new invoice using the button above.
            </p>
            <button
              onClick={onResetFilters}
              className="mt-2 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg font-medium"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <table className="w-full text-xs text-left text-slate-200">
            <thead className="text-[11px] uppercase bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th scope="col" className="px-4 py-3 font-bold text-slate-300">Invoice No.</th>
                <th scope="col" className="px-4 py-3 font-semibold">Date</th>
                <th scope="col" className="px-4 py-3 font-semibold text-right">Subtotal</th>
                <th scope="col" className="px-4 py-3 font-semibold text-right">Discount</th>
                <th scope="col" className="px-4 py-3 font-semibold text-right">VAT (15%)</th>
                <th scope="col" className="px-4 py-3 font-bold text-right text-emerald-400">Total</th>
                <th scope="col" className="px-4 py-3 font-semibold text-center">Payment Status</th>
                <th scope="col" className="px-4 py-3 font-semibold text-center">Input Method</th>
                <th scope="col" className="px-4 py-3 font-semibold text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {invoices.map((inv) => (
                <tr
                  key={inv.id}
                  className="hover:bg-slate-800/40 transition-colors group"
                >
                  {/* Invoice No */}
                  <td className="px-4 py-3 font-mono font-bold text-emerald-400 flex flex-col">
                    <span>{inv.invoiceNumber}</span>
                    <span className="text-[10px] text-slate-400 font-sans truncate max-w-[140px]">
                      {inv.sellerName}
                    </span>
                  </td>

                  {/* Date */}
                  <td className="px-4 py-3 text-slate-300 whitespace-nowrap">
                    {formatDate(inv.issueDate)}
                  </td>

                  {/* Subtotal */}
                  <td className="px-4 py-3 text-right font-mono text-slate-300">
                    {inv.subtotal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>

                  {/* Discount */}
                  <td className="px-4 py-3 text-right font-mono text-amber-400">
                    {inv.discount > 0 ? inv.discount.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'}
                  </td>

                  {/* VAT */}
                  <td className="px-4 py-3 text-right font-mono text-blue-400">
                    {inv.vatAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>

                  {/* Total */}
                  <td className="px-4 py-3 text-right font-mono font-bold text-white text-sm bg-slate-900/60">
                    {inv.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>

                  {/* Payment Status */}
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    {getStatusBadge(inv.paymentStatus)}
                    {inv.paymentStatus === 'Partially Paid' && (
                      <div className="text-[10px] text-amber-400/80 mt-0.5 font-mono">
                        Rem: {inv.remainingAmount.toLocaleString()} SAR
                      </div>
                    )}
                  </td>

                  {/* Input Method */}
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    {getInputMethodBadge(inv.inputMethod)}
                  </td>

                  {/* Action */}
                  <td className="px-4 py-3 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1.5">
                      
                      {/* View Details / Printable Invoice */}
                      <button
                        onClick={() => onViewInvoice(inv)}
                        className="p-1.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded transition-colors"
                        title="View & Print ZATCA Invoice"
                        id={`view-inv-${inv.id}`}
                      >
                        <Eye className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="sr-only">View</span>
                      </button>

                      {/* Edit Invoice */}
                      <button
                        onClick={() => onEditInvoice(inv)}
                        className="p-1.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded transition-colors"
                        title="Edit Invoice Details"
                        id={`edit-inv-${inv.id}`}
                      >
                        <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                        <span className="sr-only">Edit</span>
                      </button>

                      {/* Payment Update */}
                      <button
                        onClick={() => onRecordPayment(inv)}
                        className="p-1.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded transition-colors"
                        title="Record or Update Payment"
                        id={`pay-inv-${inv.id}`}
                      >
                        <CreditCard className="w-3.5 h-3.5 text-blue-400" />
                        <span className="sr-only">Payment</span>
                      </button>

                      {/* Delete */}
                      <button
                        onClick={() => onDeleteInvoice(inv.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 bg-slate-800 hover:bg-slate-700 border border-slate-700/80 rounded transition-colors"
                        title="Delete Invoice"
                        id={`delete-inv-${inv.id}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="sr-only">Delete</span>
                      </button>

                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

    </div>
  );
};
