import React from 'react';
import {
  Menu,
  QrCode,
  PlusCircle,
  Settings,
  ShieldCheck,
  Download,
  RefreshCw,
  Truck,
  ShieldAlert,
  Navigation,
  FileText,
} from 'lucide-react';
import { AppPanel, AppSettings } from '../types';

interface HeaderProps {
  settings: AppSettings;
  activePanel: AppPanel;
  onToggleMobileMenu: () => void;
  onOpenQRInputModal: () => void;
  onOpenSettingsModal: () => void;
  onExportCSV: () => void;
  onResetData: () => void;
  totalInvoices: number;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  activePanel,
  onToggleMobileMenu,
  onOpenQRInputModal,
  onOpenSettingsModal,
  onExportCSV,
  onResetData,
  totalInvoices,
}) => {
  const getPanelInfo = () => {
    switch (activePanel) {
      case 'invoices':
        return {
          title: 'ZATCA E-Invoices',
          titleAr: 'إدارة الفواتير الإلكترونية',
          icon: <FileText className="w-5 h-5 text-emerald-400" />,
        };
      case 'admin':
        return {
          title: 'Executive Admin & Compliance',
          titleAr: 'الامتثال والرقابة التنفيذية',
          icon: <ShieldAlert className="w-5 h-5 text-purple-400" />,
        };
      case 'dispatcher':
        return {
          title: 'Fleet Logistics & Dispatch',
          titleAr: 'إدارة أسطول النقل والحركة',
          icon: <Truck className="w-5 h-5 text-blue-400" />,
        };
      case 'driver':
        return {
          title: 'Driver Mobile & POD QR',
          titleAr: 'إثبات التسليم للعميل',
          icon: <Navigation className="w-5 h-5 text-amber-400" />,
        };
      case 'settings':
        return {
          title: 'VAT & Business Configuration',
          titleAr: 'إعدادات المنشأة والضريبة',
          icon: <Settings className="w-5 h-5 text-slate-300" />,
        };
    }
  };

  const panelInfo = getPanelInfo();

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-20 shadow-md flex-shrink-0">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Left: Mobile Menu Trigger + Active Panel Breadcrumb */}
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleMobileMenu}
              className="lg:hidden p-2 text-slate-300 hover:text-white bg-slate-800/80 border border-slate-700/60 rounded-xl transition-colors"
              aria-label="Toggle navigation menu"
              id="mobile-hamburger-btn"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-slate-800 border border-slate-700/70 rounded-xl hidden sm:flex items-center justify-center">
                {panelInfo.icon}
              </div>
              <div>
                <h1 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-2">
                  <span>{panelInfo.title}</span>
                  <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    <ShieldCheck className="w-3 h-3" />
                    ZATCA {settings.defaultPhase}
                  </span>
                  <span className="hidden lg:inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
                    Firestore Cloud Database
                  </span>
                </h1>
                <p className="text-[11px] text-slate-400 font-medium">
                  {panelInfo.titleAr} • VAT {settings.defaultVatRate}%
                </p>
              </div>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2">
            
            <button
              onClick={onResetData}
              className="hidden xl:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-colors"
              title="Reset Sample Data"
              id="reset-sample-data-btn"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Samples</span>
            </button>

            <button
              onClick={onExportCSV}
              disabled={totalInvoices === 0}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              id="export-csv-btn"
              title="Export CSV Report"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export</span>
            </button>

            <button
              onClick={onOpenSettingsModal}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 rounded-lg transition-colors"
              id="settings-btn"
              title="VAT Configuration"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Config ({settings.defaultVatRate}%)</span>
            </button>

            {/* Prominent Action Button */}
            <button
              onClick={onOpenQRInputModal}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 rounded-xl shadow-md transition-all focus:outline-none focus:ring-2 focus:ring-emerald-500/50 whitespace-nowrap"
              id="add-zatca-input-btn"
            >
              <PlusCircle className="w-4 h-4" />
              <span className="hidden xs:inline">📷 ZATCA QR / New Invoice</span>
              <span className="xs:hidden">+ Invoice</span>
            </button>
            
          </div>

        </div>
      </div>
    </header>
  );
};
