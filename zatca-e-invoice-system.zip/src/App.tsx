import React, { useState, useMemo, useEffect } from 'react';
import {
  Invoice,
  FilterState,
  DashboardMetrics,
  AppSettings,
  PaymentStatus,
  PaymentMethod,
  AppPanel,
} from './types';
import {
  getStoredInvoices,
  saveInvoicesToStorage,
  getStoredSettings,
  saveSettingsToStorage,
  DEFAULT_SETTINGS,
} from './utils/storage';
import {
  subscribeInvoices,
  subscribeSettings,
  syncInvoiceToFirestore,
  deleteInvoiceFromFirestore,
  batchSyncInvoicesToFirestore,
  syncSettingsToFirestore,
} from './utils/firebaseStorage';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ZatcaInvoicesPanel } from './components/panels/ZatcaInvoicesPanel';
import { AdminPanel } from './components/panels/AdminPanel';
import { DispatcherPanel } from './components/panels/DispatcherPanel';
import { DriverPanel } from './components/panels/DriverPanel';
import { SettingsPanel } from './components/panels/SettingsPanel';

import { QRInputModal } from './components/QRInputModal';
import { InvoiceDetailModal } from './components/InvoiceDetailModal';
import { EditInvoiceModal } from './components/EditInvoiceModal';
import { PaymentModal } from './components/PaymentModal';
import { SettingsModal } from './components/SettingsModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';

export default function App() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  // Active Panel Navigation State
  const [activePanel, setActivePanel] = useState<AppPanel>('invoices');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Modals state
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);

  const [selectedInvoiceForView, setSelectedInvoiceForView] = useState<Invoice | null>(null);
  const [selectedInvoiceForEdit, setSelectedInvoiceForEdit] = useState<Invoice | null>(null);
  const [selectedInvoiceForPayment, setSelectedInvoiceForPayment] = useState<Invoice | null>(null);
  const [selectedInvoiceForDelete, setSelectedInvoiceForDelete] = useState<Invoice | null>(null);

  // Filters State
  const [filters, setFilters] = useState<FilterState>({
    fromDate: '',
    toDate: '',
    searchQuery: '',
    paymentStatus: 'All',
    inputMethod: 'All',
  });

  // Load Initial Data from storage & subscribe to Firestore Real-time Cloud updates
  useEffect(() => {
    const loadedInvoices = getStoredInvoices();
    const loadedSettings = getStoredSettings();
    setInvoices(loadedInvoices);
    setSettings(loadedSettings);

    // Initial batch sync to ensure cloud database has seed data if empty
    if (loadedInvoices.length > 0) {
      batchSyncInvoicesToFirestore(loadedInvoices);
    }
    syncSettingsToFirestore(loadedSettings);

    // Subscribe to live Firestore updates across all devices
    const unsubscribeInvoices = subscribeInvoices((remoteInvoices) => {
      setInvoices(remoteInvoices);
      saveInvoicesToStorage(remoteInvoices);
    });

    const unsubscribeSettings = subscribeSettings((remoteSettings) => {
      setSettings(remoteSettings);
      saveSettingsToStorage(remoteSettings);
    });

    return () => {
      unsubscribeInvoices();
      unsubscribeSettings();
    };
  }, []);

  // Save Invoices on Change
  const handleUpdateInvoices = (newInvoices: Invoice[]) => {
    setInvoices(newInvoices);
    saveInvoicesToStorage(newInvoices);
  };

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveSettingsToStorage(newSettings);
    syncSettingsToFirestore(newSettings);
  };

  // Generate Next Invoice Number
  const nextInvoiceNumber = useMemo(() => {
    if (invoices.length === 0) return 'INV-1001';
    const nums = invoices
      .map((inv) => parseInt(inv.invoiceNumber.replace(/\D/g, ''), 10))
      .filter((n) => !isNaN(n));
    const maxNum = nums.length > 0 ? Math.max(...nums) : 1000;
    return `INV-${maxNum + 1}`;
  }, [invoices]);

  // Filtered Invoices Calculation
  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      // Search Query
      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase().trim();
        const matchesInvNum = inv.invoiceNumber.toLowerCase().includes(q);
        const matchesSeller = inv.sellerName.toLowerCase().includes(q);
        const matchesBuyer = (inv.buyerName || '').toLowerCase().includes(q);
        const matchesVat = inv.sellerVatNumber.includes(q);
        if (!matchesInvNum && !matchesSeller && !matchesBuyer && !matchesVat) {
          return false;
        }
      }

      // Date Range Filter
      if (filters.fromDate) {
        if (new Date(inv.issueDate) < new Date(filters.fromDate)) {
          return false;
        }
      }
      if (filters.toDate) {
        if (new Date(inv.issueDate) > new Date(filters.toDate)) {
          return false;
        }
      }

      // Payment Status
      if (filters.paymentStatus !== 'All') {
        if (inv.paymentStatus !== filters.paymentStatus) {
          return false;
        }
      }

      // Input Method
      if (filters.inputMethod !== 'All') {
        if (inv.inputMethod !== filters.inputMethod) {
          return false;
        }
      }

      return true;
    });
  }, [invoices, filters]);

  // Recalculate Dashboard Metrics automatically based on active filters
  const dashboardMetrics: DashboardMetrics = useMemo(() => {
    let totalInvoicesCount = filteredInvoices.length;
    let paidInvoicesCount = 0;
    let unpaidInvoicesCount = 0;
    let partiallyPaidCount = 0;

    let totalSubtotal = 0;
    let totalDiscount = 0;
    let taxableAmount = 0;
    let totalVatAmount = 0;
    let totalInvoiceAmount = 0;
    let totalPaidAmount = 0;
    let outstandingAmount = 0;

    for (const inv of filteredInvoices) {
      if (inv.paymentStatus === 'Paid') paidInvoicesCount++;
      else if (inv.paymentStatus === 'Unpaid') unpaidInvoicesCount++;
      else if (inv.paymentStatus === 'Partially Paid') partiallyPaidCount++;

      totalSubtotal += inv.subtotal || 0;
      totalDiscount += inv.discount || 0;
      taxableAmount += inv.taxableAmount || 0;
      totalVatAmount += inv.vatAmount || 0;
      totalInvoiceAmount += inv.totalAmount || 0;
      totalPaidAmount += inv.paidAmount || 0;
      outstandingAmount += inv.remainingAmount || 0;
    }

    return {
      totalInvoicesCount,
      paidInvoicesCount,
      unpaidInvoicesCount,
      partiallyPaidCount,
      totalSubtotal,
      totalDiscount,
      taxableAmount,
      totalVatAmount,
      totalInvoiceAmount,
      totalPaidAmount,
      outstandingAmount,
    };
  }, [filteredInvoices]);

  const isFilteredActive = useMemo(() => {
    return (
      Boolean(filters.fromDate) ||
      Boolean(filters.toDate) ||
      Boolean(filters.searchQuery) ||
      filters.paymentStatus !== 'All' ||
      filters.inputMethod !== 'All'
    );
  }, [filters]);

  const handleResetFilters = () => {
    setFilters({
      fromDate: '',
      toDate: '',
      searchQuery: '',
      paymentStatus: 'All',
      inputMethod: 'All',
    });
  };

  // Add / Save Invoice
  const handleSaveNewInvoice = (newInv: Invoice) => {
    const updated = [newInv, ...invoices];
    handleUpdateInvoices(updated);
    syncInvoiceToFirestore(newInv);
  };

  // Edit / Save Invoice
  const handleSaveEditedInvoice = (updatedInv: Invoice) => {
    const updatedList = invoices.map((inv) =>
      inv.id === updatedInv.id ? updatedInv : inv
    );
    handleUpdateInvoices(updatedList);
    syncInvoiceToFirestore(updatedInv);
  };

  // Trigger Delete Modal
  const handleDeleteInvoice = (id: string) => {
    const inv = invoices.find((i) => i.id === id);
    if (inv) {
      setSelectedInvoiceForDelete(inv);
    }
  };

  // Perform Actual Delete
  const handleConfirmDeleteInvoice = (id: string) => {
    const updated = invoices.filter((inv) => inv.id !== id);
    handleUpdateInvoices(updated);
    deleteInvoiceFromFirestore(id);
    if (selectedInvoiceForView?.id === id) {
      setSelectedInvoiceForView(null);
    }
  };

  // Update / Record Payment
  const handleSavePaymentRecord = (
    invoiceId: string,
    newStatus: PaymentStatus,
    paidAmount: number,
    paymentMethod: PaymentMethod,
    reference: string,
    notes: string
  ) => {
    let updatedTargetInvoice: Invoice | null = null;
    const updated = invoices.map((inv) => {
      if (inv.id === invoiceId) {
        const remaining = Math.max(0, inv.totalAmount - paidAmount);
        const newRecord = {
          id: 'pay-' + Date.now(),
          amount: paidAmount,
          date: new Date().toISOString().split('T')[0],
          method: paymentMethod,
          reference: reference || `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
          notes: notes || `Payment status updated to ${newStatus}`,
        };

        const target = {
          ...inv,
          paymentStatus: newStatus,
          paidAmount: paidAmount,
          remainingAmount: remaining,
          payments: [newRecord, ...(inv.payments || [])],
          updatedAt: new Date().toISOString(),
        };
        updatedTargetInvoice = target;
        return target;
      }
      return inv;
    });

    handleUpdateInvoices(updated);
    if (updatedTargetInvoice) {
      syncInvoiceToFirestore(updatedTargetInvoice);
    }
  };

  // Perform Reset Sample Data
  const handleConfirmResetSampleData = () => {
    localStorage.removeItem('zatca_invoices_db_v2');
    const resetList = getStoredInvoices();
    setInvoices(resetList);
    batchSyncInvoicesToFirestore(resetList);
    handleResetFilters();
  };

  // Export CSV Report
  const handleExportCSV = () => {
    if (filteredInvoices.length === 0) return;

    const headers = [
      'Invoice No.',
      'Date',
      'Seller Name',
      'Seller VAT',
      'Buyer Name',
      'Subtotal (SAR)',
      'Discount (SAR)',
      'Taxable (SAR)',
      'VAT (SAR)',
      'Total (SAR)',
      'Paid (SAR)',
      'Outstanding (SAR)',
      'Payment Status',
      'Input Method',
    ];

    const rows = filteredInvoices.map((inv) => [
      inv.invoiceNumber,
      inv.issueDate,
      `"${inv.sellerName.replace(/"/g, '""')}"`,
      inv.sellerVatNumber,
      `"${(inv.buyerName || '').replace(/"/g, '""')}"`,
      inv.subtotal.toFixed(2),
      inv.discount.toFixed(2),
      inv.taxableAmount.toFixed(2),
      inv.vatAmount.toFixed(2),
      inv.totalAmount.toFixed(2),
      inv.paidAmount.toFixed(2),
      inv.remainingAmount.toFixed(2),
      inv.paymentStatus,
      inv.inputMethod,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ZATCA_Invoice_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="h-screen w-screen overflow-hidden bg-slate-950 text-slate-100 flex font-sans antialiased">
      
      {/* Fixed Left Navigation Sidebar */}
      <Sidebar
        activePanel={activePanel}
        onSelectPanel={setActivePanel}
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
        totalInvoicesCount={invoices.length}
        settings={settings}
      />

      {/* Main Right Frame Column */}
      <div className="flex-1 flex flex-col h-screen min-w-0 overflow-hidden">
        
        {/* Fixed Top Header */}
        <Header
          settings={settings}
          activePanel={activePanel}
          onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          onOpenQRInputModal={() => setIsQRModalOpen(true)}
          onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
          onExportCSV={handleExportCSV}
          onResetData={() => setIsResetModalOpen(true)}
          totalInvoices={invoices.length}
        />

        {/* Scrollable Main Viewport Area */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-6 lg:p-8 space-y-8">
          <div className="max-w-7xl mx-auto w-full">
            
            {activePanel === 'invoices' && (
              <ZatcaInvoicesPanel
                metrics={dashboardMetrics}
                filteredInvoices={filteredInvoices}
                filters={filters}
                onFilterChange={setFilters}
                onResetFilters={handleResetFilters}
                isFilteredActive={isFilteredActive}
                onViewInvoice={(inv) => setSelectedInvoiceForView(inv)}
                onEditInvoice={(inv) => setSelectedInvoiceForEdit(inv)}
                onRecordPayment={(inv) => {
                  setSelectedInvoiceForPayment(inv);
                  setIsPaymentModalOpen(true);
                }}
                onDeleteInvoice={handleDeleteInvoice}
              />
            )}

            {activePanel === 'admin' && (
              <AdminPanel
                metrics={dashboardMetrics}
                invoices={invoices}
                settings={settings}
                onResetData={() => setIsResetModalOpen(true)}
                onOpenQRInputModal={() => setIsQRModalOpen(true)}
                onOpenSettingsModal={() => setIsSettingsModalOpen(true)}
              />
            )}

            {activePanel === 'dispatcher' && (
              <DispatcherPanel
                invoices={invoices}
                onViewInvoice={(inv) => setSelectedInvoiceForView(inv)}
                onOpenQRInputModal={() => setIsQRModalOpen(true)}
              />
            )}

            {activePanel === 'driver' && (
              <DriverPanel
                invoices={invoices}
                onViewInvoice={(inv) => setSelectedInvoiceForView(inv)}
                onOpenQRInputModal={() => setIsQRModalOpen(true)}
              />
            )}

            {activePanel === 'settings' && (
              <SettingsPanel
                settings={settings}
                onSaveSettings={handleUpdateSettings}
                onResetData={() => setIsResetModalOpen(true)}
              />
            )}

          </div>

          {/* Unified Frame Footer */}
          <footer className="border-t border-slate-900 pt-6 pb-2 text-center text-xs text-slate-500">
            <p>
              ZATCA E-Invoicing Phase 1 & Phase 2 Module • KSA VAT Regulation Compliant (15%) • Unified Application Frame
            </p>
          </footer>
        </main>

      </div>

      {/* Global Modals */}
      <QRInputModal
        isOpen={isQRModalOpen}
        onClose={() => setIsQRModalOpen(false)}
        onSaveInvoice={handleSaveNewInvoice}
        settings={settings}
        nextInvoiceNumber={nextInvoiceNumber}
      />

      <InvoiceDetailModal
        invoice={selectedInvoiceForView}
        onClose={() => setSelectedInvoiceForView(null)}
        onOpenPaymentModal={(inv) => {
          setSelectedInvoiceForView(null);
          setSelectedInvoiceForPayment(inv);
          setIsPaymentModalOpen(true);
        }}
        onEditInvoice={(inv) => {
          setSelectedInvoiceForView(null);
          setSelectedInvoiceForEdit(inv);
        }}
        onDeleteInvoice={handleDeleteInvoice}
      />

      <EditInvoiceModal
        isOpen={Boolean(selectedInvoiceForEdit)}
        invoice={selectedInvoiceForEdit}
        onClose={() => setSelectedInvoiceForEdit(null)}
        onSaveInvoice={handleSaveEditedInvoice}
      />

      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setSelectedInvoiceForPayment(null);
        }}
        invoice={selectedInvoiceForPayment}
        onSavePayment={handleSavePaymentRecord}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onSaveSettings={handleUpdateSettings}
      />

      <DeleteConfirmModal
        isOpen={Boolean(selectedInvoiceForDelete)}
        invoice={selectedInvoiceForDelete}
        onClose={() => setSelectedInvoiceForDelete(null)}
        onConfirmDelete={handleConfirmDeleteInvoice}
      />

      <ResetConfirmModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onConfirmReset={handleConfirmResetSampleData}
      />

    </div>
  );
}
