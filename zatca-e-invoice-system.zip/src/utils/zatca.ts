import { ZATCAQRData, LineItem, Invoice, InvoicePhase } from '../types';

/**
 * Encodes ZATCA data into TLV (Tag-Length-Value) format and converts to Base64 string.
 * According to ZATCA Phase 1 & Phase 2 specifications:
 * Tag 1: Seller's Name
 * Tag 2: VAT Registration Number
 * Tag 3: Timestamp (ISO 8601)
 * Tag 4: Invoice Total (with VAT)
 * Tag 5: VAT Total
 * Tag 6: Hash of XML Invoice (Phase 2)
 * Tag 7: ECDSA Digital Signature (Phase 2)
 * Tag 8: ECDSA Public Key (Phase 2)
 * Tag 9: Cryptographic Stamp Certificate Signature (Phase 2)
 */
export function encodeZATCATLV(data: {
  sellerName: string;
  vatNumber: string;
  timestamp: string;
  totalAmount: number;
  vatAmount: number;
  invoiceHash?: string;
  ecdsaSignature?: string;
  ecdsaPublicKey?: string;
  certificateSignature?: string;
}): string {
  const encoder = new TextEncoder();
  const buffers: Uint8Array[] = [];

  const addTag = (tagNumber: number, valueStr: string) => {
    if (!valueStr) return;
    const valueBytes = encoder.encode(valueStr);
    const tagByte = tagNumber;
    const lengthByte = valueBytes.length;

    const tlvBuffer = new Uint8Array(2 + valueBytes.length);
    tlvBuffer[0] = tagByte;
    tlvBuffer[1] = lengthByte;
    tlvBuffer.set(valueBytes, 2);

    buffers.push(tlvBuffer);
  };

  addTag(1, data.sellerName || '');
  addTag(2, data.vatNumber || '');
  addTag(3, data.timestamp || new Date().toISOString());
  addTag(4, data.totalAmount.toFixed(2));
  addTag(5, data.vatAmount.toFixed(2));

  if (data.invoiceHash) addTag(6, data.invoiceHash);
  if (data.ecdsaSignature) addTag(7, data.ecdsaSignature);
  if (data.ecdsaPublicKey) addTag(8, data.ecdsaPublicKey);
  if (data.certificateSignature) addTag(9, data.certificateSignature);

  // Total length calculation
  const totalLength = buffers.reduce((acc, buf) => acc + buf.length, 0);
  const combined = new Uint8Array(totalLength);
  let offset = 0;
  for (const buf of buffers) {
    combined.set(buf, offset);
    offset += buf.length;
  }

  // Convert binary Uint8Array to base64
  let binary = '';
  const bytes = new Uint8Array(combined);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Decodes a ZATCA Base64 TLV string into structured QR data.
 */
export function decodeZATCATLV(base64Str: string): ZATCAQRData | null {
  try {
    const cleanedBase64 = base64Str.trim().replace(/\s+/g, '');
    const binaryStr = atob(cleanedBase64);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }

    const decoder = new TextDecoder('utf-8');
    let offset = 0;

    const result: Partial<ZATCAQRData> = {
      rawBase64: cleanedBase64,
    };

    while (offset < bytes.length) {
      if (offset + 2 > bytes.length) break;

      const tag = bytes[offset];
      const length = bytes[offset + 1];
      offset += 2;

      if (offset + length > bytes.length) break;

      const valueBytes = bytes.subarray(offset, offset + length);
      const value = decoder.decode(valueBytes);
      offset += length;

      switch (tag) {
        case 1:
          result.sellerName = value;
          break;
        case 2:
          result.vatNumber = value;
          break;
        case 3:
          result.timestamp = value;
          break;
        case 4:
          result.totalAmount = parseFloat(value) || 0;
          break;
        case 5:
          result.vatAmount = parseFloat(value) || 0;
          break;
        case 6:
          result.invoiceHash = value;
          break;
        case 7:
          result.ecdsaSignature = value;
          break;
        case 8:
          result.ecdsaPublicKey = value;
          break;
        case 9:
          result.certificateSignature = value;
          break;
      }
    }

    if (
      result.sellerName !== undefined ||
      result.vatNumber !== undefined ||
      result.totalAmount !== undefined
    ) {
      return {
        sellerName: result.sellerName || 'Unknown Seller',
        vatNumber: result.vatNumber || '300000000000003',
        timestamp: result.timestamp || new Date().toISOString(),
        totalAmount: result.totalAmount || 0,
        vatAmount: result.vatAmount || 0,
        invoiceHash: result.invoiceHash,
        ecdsaSignature: result.ecdsaSignature,
        ecdsaPublicKey: result.ecdsaPublicKey,
        certificateSignature: result.certificateSignature,
        rawBase64: cleanedBase64,
      };
    }

    return null;
  } catch (err) {
    console.error('Failed to decode ZATCA TLV Base64:', err);
    return null;
  }
}

/**
 * Validates Saudi Arabia VAT Number (15 digits, starting and ending with 3)
 */
export function validateKSACompanyVat(vatNumber: string): boolean {
  const cleanVat = vatNumber.trim();
  return /^3\d{13}3$/.test(cleanVat);
}

/**
 * Recalculates line items and invoice totals given custom VAT %
 */
export function calculateInvoiceTotals(
  items: LineItem[],
  invoiceLevelDiscount: number = 0,
  vatRate: number = 15
): {
  subtotal: number;
  discount: number;
  taxableAmount: number;
  vatAmount: number;
  totalAmount: number;
  itemsWithCalculations: LineItem[];
} {
  let subtotal = 0;
  let totalItemDiscount = 0;

  const itemsWithCalculations = items.map((item) => {
    const rawLineSubtotal = item.quantity * item.unitPrice;
    const itemDiscount = Math.min(item.discount || 0, rawLineSubtotal);
    const taxableAmount = Math.max(0, rawLineSubtotal - itemDiscount);
    const itemVatAmount = taxableAmount * (vatRate / 100);
    const itemTotalAmount = taxableAmount + itemVatAmount;

    subtotal += rawLineSubtotal;
    totalItemDiscount += itemDiscount;

    return {
      ...item,
      vatRate,
      taxableAmount,
      vatAmount: itemVatAmount,
      totalAmount: itemTotalAmount,
    };
  });

  const totalDiscount = totalItemDiscount + (invoiceLevelDiscount || 0);
  const taxableAmount = Math.max(0, subtotal - totalDiscount);
  const vatAmount = taxableAmount * (vatRate / 100);
  const totalAmount = taxableAmount + vatAmount;

  return {
    subtotal,
    discount: totalDiscount,
    taxableAmount,
    vatAmount,
    totalAmount,
    itemsWithCalculations,
  };
}

/**
 * Generates mock ZATCA Phase 2 Hash & ECDSA Signature for simulation
 */
export function generatePhase2SecurityData(): {
  uuid: string;
  invoiceHash: string;
  ecdsaSignature: string;
} {
  const uuid = crypto.randomUUID();
  const rawStr = `ZATCA-P2-${uuid}-${Date.now()}`;
  
  // Mock Base64 hash
  let hash = '';
  try {
    hash = btoa(rawStr).substring(0, 32) + '==';
  } catch {
    hash = 'MEUCIQDxZATCA2026Base64HashSignatureSample==';
  }

  const ecdsaSignature = `MEQCIDZATCA_ECDSA_SIG_${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

  return {
    uuid,
    invoiceHash: hash,
    ecdsaSignature,
  };
}

/**
 * Format currency in Saudi Riyals (SAR)
 */
export function formatSAR(amount: number): string {
  return new Intl.NumberFormat('en-SA', {
    style: 'currency',
    currency: 'SAR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount || 0);
}

/**
 * Format Date to DD/MM/YYYY or readable localized date
 */
export function formatDate(dateString: string): string {
  if (!dateString) return '';
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
}
