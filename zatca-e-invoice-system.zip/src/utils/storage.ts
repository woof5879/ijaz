import { Invoice, AppSettings } from '../types';
import { encodeZATCATLV, generatePhase2SecurityData } from './zatca';

const INVOICES_STORAGE_KEY = 'zatca_invoices_db_v2';
const SETTINGS_STORAGE_KEY = 'zatca_app_settings_v2';

export const DEFAULT_SETTINGS: AppSettings = {
  defaultVatRate: 15,
  currencySymbol: 'SAR',
  companyName: 'Al-Khobar Technology Solutions LLC',
  companyNameAr: 'شركة حلول الخبر للتقنية ذ.م.م',
  vatNumber: '310123456700003',
  companyAddress: 'King Fahd Road, Olaya District, Riyadh, Kingdom of Saudi Arabia',
  defaultPhase: 'Phase 2 (Integration/Standard)',
};

// Initial Seed Invoices based on user prompt requirements
const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-1001',
    invoiceNumber: 'INV-1001',
    uuid: '8f2a9310-2b10-48e0-a291-723bf1920001',
    issueDate: '2026-08-13',
    issueTime: '10:15',
    sellerName: 'Al-Khobar Technology Solutions LLC',
    sellerNameAr: 'شركة حلول الخبر للتقنية ذ.م.م',
    sellerVatNumber: '310123456700003',
    sellerAddress: 'Riyadh, KSA',
    buyerName: 'Advanced Logistics Trading Co.',
    buyerNameAr: 'شركة اللوجستيات المتقدمة للتجارة',
    buyerVatNumber: '300987654300003',
    items: [
      {
        id: 'item-1',
        description: 'IT Consulting & Cloud Server Setup',
        descriptionAr: 'استشارات تقنية وإعداد خوادم سحابية',
        quantity: 1,
        unitPrice: 1000,
        discount: 100,
        vatRate: 15,
        taxableAmount: 900,
        vatAmount: 135,
        totalAmount: 1035,
      },
    ],
    subtotal: 1000,
    discount: 100,
    taxableAmount: 900,
    vatRate: 15,
    vatAmount: 135,
    totalAmount: 1035,
    paymentStatus: 'Paid',
    paidAmount: 1035,
    remainingAmount: 0,
    payments: [
      {
        id: 'pay-101',
        amount: 1035,
        date: '2026-08-13',
        method: 'Mada',
        reference: 'MADA-TXN-99881',
        notes: 'Full payment cleared via POS terminal',
      },
    ],
    inputMethod: 'QR Scan',
    phase: 'Phase 2 (Integration/Standard)',
    qrBase64: encodeZATCATLV({
      sellerName: 'Al-Khobar Technology Solutions LLC',
      vatNumber: '310123456700003',
      timestamp: '2026-08-13T10:15:00Z',
      totalAmount: 1035,
      vatAmount: 135,
      invoiceHash: 'MEUCIQDxZATCA2026Base64HashSignatureSample==',
    }),
    zatcaHash: 'MEUCIQDxZATCA2026Base64HashSignatureSample==',
    isClearedByZATCA: true,
    createdAt: '2026-08-13T10:15:00Z',
    updatedAt: '2026-08-13T10:15:00Z',
  },
  {
    id: 'inv-1002',
    invoiceNumber: 'INV-1002',
    uuid: '9e3b8211-1a20-49f1-b382-834cf2830002',
    issueDate: '2026-08-13',
    issueTime: '11:30',
    sellerName: 'Al-Khobar Technology Solutions LLC',
    sellerNameAr: 'شركة حلول الخبر للتقنية ذ.م.م',
    sellerVatNumber: '310123456700003',
    sellerAddress: 'Riyadh, KSA',
    buyerName: 'National Construction Enterprise',
    buyerNameAr: 'مؤسسة الإنشاءات الوطنية',
    buyerVatNumber: '300112233400003',
    items: [
      {
        id: 'item-2',
        description: 'Network Infrastructure Hardware Hardware Supply',
        descriptionAr: 'توريد أجهزة ومعدات البنية التحتية للشبكات',
        quantity: 2,
        unitPrice: 1000,
        discount: 0,
        vatRate: 15,
        taxableAmount: 2000,
        vatAmount: 300,
        totalAmount: 2300,
      },
    ],
    subtotal: 2000,
    discount: 0,
    taxableAmount: 2000,
    vatRate: 15,
    vatAmount: 300,
    totalAmount: 2300,
    paymentStatus: 'Unpaid',
    paidAmount: 0,
    remainingAmount: 2300,
    payments: [],
    inputMethod: 'Manual',
    phase: 'Phase 1 (Simplified)',
    qrBase64: encodeZATCATLV({
      sellerName: 'Al-Khobar Technology Solutions LLC',
      vatNumber: '310123456700003',
      timestamp: '2026-08-13T11:30:00Z',
      totalAmount: 2300,
      vatAmount: 300,
    }),
    createdAt: '2026-08-13T11:30:00Z',
    updatedAt: '2026-08-13T11:30:00Z',
  },
  {
    id: 'inv-1003',
    invoiceNumber: 'INV-1003',
    uuid: generatePhase2SecurityData().uuid,
    issueDate: '2026-08-12',
    issueTime: '14:45',
    sellerName: 'Saudi Electronics & Supplies',
    sellerNameAr: 'الشركة السعودية للإلكترونيات والتوريدات',
    sellerVatNumber: '311889900100003',
    sellerAddress: 'Jeddah, KSA',
    buyerName: 'Al-Khobar Technology Solutions LLC',
    buyerVatNumber: '310123456700003',
    items: [
      {
        id: 'item-3',
        description: 'Server Rack & Fiber Optic Cable Bundles',
        quantity: 4,
        unitPrice: 1000,
        discount: 200,
        vatRate: 15,
        taxableAmount: 3800,
        vatAmount: 570,
        totalAmount: 4370,
      },
    ],
    subtotal: 4000,
    discount: 200,
    taxableAmount: 3800,
    vatRate: 15,
    vatAmount: 570,
    totalAmount: 4370,
    paymentStatus: 'Partially Paid',
    paidAmount: 2000,
    remainingAmount: 2370,
    payments: [
      {
        id: 'pay-102',
        amount: 2000,
        date: '2026-08-12',
        method: 'Bank Transfer',
        reference: 'SA-BNK-4421',
        notes: 'Initial 50% deposit received',
      },
    ],
    inputMethod: 'Base64 Paste',
    phase: 'Phase 2 (Integration/Standard)',
    qrBase64: encodeZATCATLV({
      sellerName: 'Saudi Electronics & Supplies',
      vatNumber: '311889900100003',
      timestamp: '2026-08-12T14:45:00Z',
      totalAmount: 4370,
      vatAmount: 570,
      invoiceHash: 'MEQCIDxZATCA2026Base64HashSignatureSample3==',
    }),
    isClearedByZATCA: true,
    createdAt: '2026-08-12T14:45:00Z',
    updatedAt: '2026-08-12T14:45:00Z',
  },
];

export function getStoredInvoices(): Invoice[] {
  try {
    const raw = localStorage.getItem(INVOICES_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(INVOICES_STORAGE_KEY, JSON.stringify(INITIAL_INVOICES));
      return INITIAL_INVOICES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_INVOICES;
  } catch (err) {
    console.error('Failed to load stored invoices:', err);
    return INITIAL_INVOICES;
  }
}

export function saveInvoicesToStorage(invoices: Invoice[]): void {
  try {
    localStorage.setItem(INVOICES_STORAGE_KEY, JSON.stringify(invoices));
  } catch (err) {
    console.error('Failed to save invoices to storage:', err);
  }
}

export function getStoredSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(DEFAULT_SETTINGS));
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (err) {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettingsToStorage(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save app settings:', err);
  }
}
