import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDocs,
  onSnapshot,
  query,
  orderBy,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Invoice, AppSettings, DispatchWaybill, DriverTrip } from '../types';

const INVOICES_COLLECTION = 'invoices';
const WAYBILLS_COLLECTION = 'waybills';
const DRIVER_TRIPS_COLLECTION = 'driverTrips';
const SETTINGS_COLLECTION = 'settings';

// Real-time listener for Invoices
export function subscribeInvoices(
  onUpdate: (invoices: Invoice[]) => void,
  onError?: (err: Error) => void
) {
  try {
    const q = query(collection(db, INVOICES_COLLECTION));
    return onSnapshot(
      q,
      (snapshot) => {
        const invoices: Invoice[] = [];
        snapshot.forEach((docSnap) => {
          invoices.push(docSnap.data() as Invoice);
        });
        if (invoices.length > 0) {
          // Sort by issueDate descending
          invoices.sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
          onUpdate(invoices);
        }
      },
      (error) => {
        console.warn('Firestore invoices snapshot subscription error (using local cache):', error);
        if (onError) onError(error);
      }
    );
  } catch (err) {
    console.warn('Firestore subscription initialized failed:', err);
    return () => {};
  }
}

// Save or Update Single Invoice to Firestore
export async function syncInvoiceToFirestore(invoice: Invoice): Promise<void> {
  try {
    const docRef = doc(db, INVOICES_COLLECTION, invoice.id);
    await setDoc(docRef, invoice, { merge: true });
  } catch (err) {
    console.error('Failed to sync invoice to Firestore:', err);
  }
}

// Delete Invoice from Firestore
export async function deleteInvoiceFromFirestore(invoiceId: string): Promise<void> {
  try {
    const docRef = doc(db, INVOICES_COLLECTION, invoiceId);
    await deleteDoc(docRef);
  } catch (err) {
    console.error('Failed to delete invoice from Firestore:', err);
  }
}

// Batch Sync All Invoices (e.g. on seed or reset)
export async function batchSyncInvoicesToFirestore(invoices: Invoice[]): Promise<void> {
  try {
    const batch = writeBatch(db);
    invoices.forEach((inv) => {
      const docRef = doc(db, INVOICES_COLLECTION, inv.id);
      batch.set(docRef, inv, { merge: true });
    });
    await batch.commit();
  } catch (err) {
    console.error('Failed to batch sync invoices to Firestore:', err);
  }
}

// Real-time listener for Dispatch Waybills
export function subscribeWaybills(
  onUpdate: (waybills: DispatchWaybill[]) => void
) {
  try {
    const q = query(collection(db, WAYBILLS_COLLECTION));
    return onSnapshot(
      q,
      (snapshot) => {
        const list: DispatchWaybill[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as DispatchWaybill);
        });
        if (list.length > 0) {
          onUpdate(list);
        }
      },
      (err) => console.warn('Firestore waybills snapshot error:', err)
    );
  } catch (err) {
    return () => {};
  }
}

export async function syncWaybillToFirestore(waybill: DispatchWaybill): Promise<void> {
  try {
    const docRef = doc(db, WAYBILLS_COLLECTION, waybill.id);
    await setDoc(docRef, waybill, { merge: true });
  } catch (err) {
    console.error('Failed to sync waybill to Firestore:', err);
  }
}

// Real-time listener for Driver Trips
export function subscribeDriverTrips(
  onUpdate: (trips: DriverTrip[]) => void
) {
  try {
    const q = query(collection(db, DRIVER_TRIPS_COLLECTION));
    return onSnapshot(
      q,
      (snapshot) => {
        const list: DriverTrip[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as DriverTrip);
        });
        if (list.length > 0) {
          onUpdate(list);
        }
      },
      (err) => console.warn('Firestore driver trips snapshot error:', err)
    );
  } catch (err) {
    return () => {};
  }
}

export async function syncDriverTripToFirestore(trip: DriverTrip): Promise<void> {
  try {
    const docRef = doc(db, DRIVER_TRIPS_COLLECTION, trip.id);
    await setDoc(docRef, trip, { merge: true });
  } catch (err) {
    console.error('Failed to sync driver trip to Firestore:', err);
  }
}

// Sync Settings
export async function syncSettingsToFirestore(settings: AppSettings): Promise<void> {
  try {
    const docRef = doc(db, SETTINGS_COLLECTION, 'main_config');
    await setDoc(docRef, settings, { merge: true });
  } catch (err) {
    console.error('Failed to sync settings to Firestore:', err);
  }
}

export function subscribeSettings(onUpdate: (settings: AppSettings) => void) {
  try {
    const docRef = doc(db, SETTINGS_COLLECTION, 'main_config');
    return onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        onUpdate(docSnap.data() as AppSettings);
      }
    });
  } catch (err) {
    return () => {};
  }
}
