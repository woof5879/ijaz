export type PaymentStatus = 'Paid' | 'Unpaid' | 'Partially Paid';

export type InputMethod = 'QR Scan' | 'Manual' | 'Base64 Paste';

export type InvoicePhase = 'Phase 1 (Simplified)' | 'Phase 2 (Integration/Standard)';

export type PaymentMethod = 'Bank Transfer' | 'Mada' | 'Visa/Mastercard' | 'Cash' | 'POS' | 'Cheque';

export interface PaymentRecord {
  id: string;
  amount: number;
  date: string;
  method: PaymentMethod;
  reference?: string;
  notes?: string;
}

export interface LineItem {
  id: string;
  description: string;
  descriptionAr?: string;
  quantity: number;
  unitPrice: number;
  discount: number; // Amount or percentage based on mode
  vatRate: number; // e.g., 15
  taxableAmount: number; // (quantity * unitPrice) - discount
  vatAmount: number; // taxableAmount * (vatRate / 100)
  totalAmount: number; // taxableAmount + vatAmount
}

export interface ZATCAQRData {
  sellerName: string;
  vatNumber: string; // 15 digits
  timestamp: string; // ISO string
  totalAmount: number;
  vatAmount: number;
  // Phase 2 Fields
  invoiceHash?: string;
  ecdsaSignature?: string;
  ecdsaPublicKey?: string;
  certificateSignature?: string;
  rawBase64?: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g. INV-1001
  uuid?: string; // Phase 2 requirement
  issueDate: string; // YYYY-MM-DD
  issueTime: string; // HH:mm
  
  // Seller Details
  sellerName: string;
  sellerNameAr?: string;
  sellerVatNumber: string;
  sellerAddress?: string;
  sellerBuildingNo?: string;
  sellerPostalCode?: string;

  // Buyer Details
  buyerName?: string;
  buyerNameAr?: string;
  buyerVatNumber?: string;
  buyerAddress?: string;

  // Invoice Items & Calculations
  items: LineItem[];
  subtotal: number;
  discount: number; // Total invoice level discount
  taxableAmount: number;
  vatRate: number; // Default 15%
  vatAmount: number;
  totalAmount: number;

  // Payment Tracking
  paymentStatus: PaymentStatus;
  paidAmount: number;
  remainingAmount: number;
  payments: PaymentRecord[];

  // ZATCA Metadata
  inputMethod: InputMethod;
  phase: InvoicePhase;
  qrBase64: string;
  zatcaHash?: string;
  isClearedByZATCA?: boolean; // Phase 2 clearance status
  notes?: string;

  createdAt: string;
  updatedAt: string;
}

export interface FilterState {
  fromDate: string;
  toDate: string;
  searchQuery: string; // Invoice No / Seller / Buyer
  paymentStatus: 'All' | PaymentStatus;
  inputMethod: 'All' | InputMethod;
}

export interface DashboardMetrics {
  totalInvoicesCount: number;
  paidInvoicesCount: number;
  unpaidInvoicesCount: number;
  partiallyPaidCount: number;
  
  totalSubtotal: number;
  totalDiscount: number;
  taxableAmount: number;
  totalVatAmount: number;
  totalInvoiceAmount: number;
  
  totalPaidAmount: number;
  outstandingAmount: number;
}

export interface AppSettings {
  defaultVatRate: number; // 15
  currencySymbol: string; // SAR
  companyName: string;
  companyNameAr: string;
  vatNumber: string;
  companyAddress: string;
  defaultPhase: InvoicePhase;
}

export type AppPanel = 'invoices' | 'admin' | 'dispatcher' | 'driver' | 'settings';

export interface DispatchWaybill {
  id: string;
  waybillNumber: string; // e.g. WB-5012
  originCity: string;
  destinationCity: string;
  assignedDriver: string;
  truckPlate: string;
  invoiceNumber: string;
  totalWeightKg: number;
  status: 'Pending' | 'In Transit' | 'Delivered' | 'Cancelled';
  estimatedDelivery: string;
  dispatchDate: string;
}

export interface DriverTrip {
  id: string;
  tripNumber: string;
  route: string;
  customerName: string;
  deliveryAddress: string;
  invoiceNumber: string;
  invoiceAmount: number;
  status: 'Assigned' | 'En Route' | 'Arrived' | 'Completed';
  podStatus: 'Pending QR' | 'Verified' | 'Signed';
  scheduledTime: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userRole: 'Admin' | 'Dispatcher' | 'Driver' | 'System';
  action: string;
  details: string;
  ipAddress?: string;
}

